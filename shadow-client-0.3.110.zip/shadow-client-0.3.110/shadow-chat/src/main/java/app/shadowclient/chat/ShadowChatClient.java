package app.shadowclient.chat;

import app.shadowclient.chat.config.AuthConfig;
import app.shadowclient.chat.config.ModConfig;
import app.shadowclient.chat.ipc.CommandFile;
import app.shadowclient.chat.minigame.MinigameCommands;
import app.shadowclient.chat.minigame.Minigames;
import app.shadowclient.chat.qol.Qol;
import app.shadowclient.chat.qol.QolCommands;
import app.shadowclient.chat.relay.Messages;
import app.shadowclient.chat.relay.RelayClient;
import app.shadowclient.chat.ui.ChatOverlay;
import app.shadowclient.chat.ui.DiscordChatScreen;
import app.shadowclient.chat.ui.InputState;
import app.shadowclient.chat.ui.Keybinds;
import app.shadowclient.chat.voice.VoiceController;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.UUID;

/**
 * Top-level entry point for the Shadow Chat mod.
 *
 * <p>Coordinates the moving pieces:
 * <ul>
 *   <li>Loads {@link AuthConfig} (launcher-written) and {@link ModConfig} (mod-owned) at startup.</li>
 *   <li>Owns the singleton {@link RelayClient} and routes its callbacks
 *       back to {@link InputState} via the Minecraft client thread.</li>
 *   <li>Listens for join/disconnect events on multiplayer servers and
 *       opens/closes WebSocket connections accordingly.</li>
 *   <li>Drives the hotkey → overlay focus flow.</li>
 *   <li>Parses slash commands typed in the overlay's input field.</li>
 * </ul>
 *
 * <p>Exposed as a process-wide singleton because Fabric mod entrypoints
 * are constructed by the loader and several leaf classes (the overlay,
 * the input screen) need a stable handle without dragging the instance
 * through their constructors.
 */
public final class ShadowChatClient implements ClientModInitializer {

    private static final Logger LOG = LoggerFactory.getLogger("shadow-chat");

    private static ShadowChatClient instance;
    /** @return the global singleton, initialized once Fabric calls {@link #onInitializeClient()}. */
    public static ShadowChatClient get() {
        if (instance == null) throw new IllegalStateException("ShadowChatClient not yet initialized");
        return instance;
    }

    private AuthConfig auth;
    private ModConfig modConfig;
    private InputState uiState;
    private ChatOverlay overlay;
    private RelayClient relay;
    private VoiceController voice;

    /** Last status line to show in the overlay banner (auth state, connection state, …). */
    private volatile String statusLine = "";

    /**
     * Whether we've sent {@code voice:join} on the current connection.
     * Reset on every channel switch / disconnect — the relay forgets
     * opt-in state when the socket closes.
     */
    private volatile boolean inVoice = false;

    /**
     * Click-to-talk state from the chat screen's mic button. When true
     * we transmit continuously (hot mic) regardless of the PTT
     * keybind. Reset by clicking the mic again or by closing the chat
     * with no chat-screen click for safety; ORed with PTT keybind in
     * the tick handler so both inputs work.
     */
    private volatile boolean hotMicOn = false;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOG.info("Shadow Chat initializing…");

        // Configs first — overlay rendering and connect attempts both
        // depend on having these loaded.
        this.auth = AuthConfig.load();
        this.modConfig = ModConfig.load();
        this.uiState = new InputState();
        this.uiState.setActiveChannel(modConfig.activeChannel());

        this.overlay = new ChatOverlay(uiState, modConfig);
        this.overlay.register();

        Keybinds.register();

        // Minigame QoL pack — speed HUD, lap timer, ice highlighter,
        // auto-sprint, auto-respawn. All session-scoped toggles driven
        // by slash commands typed in the chat overlay; the mod stays
        // dormant until the user enables one.
        Minigames.register();

        // General QoL pack — recipe-preview tooltip, coords HUD,
        // held-item HUD. Same opt-in shape as the minigame pack.
        Qol.register();

        // Restore persisted helper toggles so /coordshud etc. survive a
        // restart instead of needing re-enabling every session. The lap
        // timer is intentionally absent — its start line is per-track.
        Minigames.speedHudEnabled     = modConfig.helperToggle("speed_hud");
        Minigames.iceHighlightEnabled = modConfig.helperToggle("ice_highlight");
        Minigames.autoSprintEnabled   = modConfig.helperToggle("auto_sprint");
        Minigames.autoRespawnEnabled  = modConfig.helperToggle("auto_respawn");
        Qol.recipePreviewEnabled      = modConfig.helperToggle("recipe_preview");
        Qol.coordsHudEnabled          = modConfig.helperToggle("coords_hud");
        Qol.heldItemHudEnabled        = modConfig.helperToggle("held_item_hud");
        Qol.cooldownHudEnabled        = modConfig.helperToggle("cooldown_hud");

        // IPC drop-file watcher — lets the launcher signal us to (e.g.)
        // open the chat screen automatically on world load. See
        // CommandFile for the JSON schema.
        new CommandFile().register();

        this.relay = new RelayClient(auth);
        // Voice runs alongside text on the same WebSocket. Initialized
        // here so audio hardware is open before the first channel join.
        // If mic/output aren't available the controller logs once and
        // stays a no-op; nothing else in the mod cares.
        this.voice = new VoiceController();
        this.voice.init(relay);
        // Restore the persisted mute state — settings panel writes it,
        // and the playback line was just constructed with muted=false.
        this.voice.playback().setMuted(modConfig.voiceMuted());

        // Set initial banner so the overlay says something useful even
        // before the player joins a server.
        if (!auth.isUsable()) {
            statusLine = "Not signed in - chat disabled";
        } else {
            statusLine = "Signed in as " + auth.name();
        }

        // ---- lifecycle wiring ----

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            // Nothing to do beyond what we already did in onInitializeClient.
            // Hook is here so a future implementation can defer heavy
            // init until the window is up without changing call sites.
            LOG.info("Shadow Chat ready (auth={})", auth.isUsable() ? "yes" : "no");
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            // Best-effort cleanup — Loom dev runs sometimes leave
            // sockets dangling otherwise.
            try { relay.disconnect(); } catch (Exception ignored) {}
            try { voice.shutdown(); } catch (Exception ignored) {}
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String channel = deriveServerChannel(client);
            if (channel == null) {
                statusLine = "Singleplayer - server chat unavailable";
                return;
            }
            if (!auth.isUsable()) {
                // Don't even try connecting; keep the banner clear about why.
                statusLine = "Not signed in - chat disabled";
                return;
            }
            // Auto-join the server channel on every join. If the user
            // had a group selected last session we still connect to
            // the server channel first; the chip switcher lets them
            // jump back.
            connectTo(ModConfig.CHANNEL_SERVER);

            // Optional: pop the chat screen open ~1 s after world load
            // when the user has opted in via /auto-open-chat. We delay
            // so the world finishes rendering first — opening Screen
            // mid-load can wedge MC's resource manager.
            if (modConfig.autoOpenChatOnJoin()) {
                scheduleAutoOpenChat(20);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            statusLine = "Disconnected from server";
            inVoice = false;
            try { relay.disconnect(); } catch (Exception ignored) {}
        });

        // Hotkey poll. consumeClick() drains the queued GLFW press
        // events so we react exactly once per tap. The PTT key is a
        // hold-style binding so we read isDown() each tick rather than
        // draining click events.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickAutoOpenChat(client);
            tickReconnectCountdown();
            tickAuthReload();
            tickPendingLeft();
            while (Keybinds.TOGGLE_CHAT.consumeClick()) {
                handleToggleHotkey(client);
            }
            // Transmission is the union of two inputs:
            //   - PTT keybind held + no Screen open (so V-as-paste in
            //     our own chat input doesn't accidentally hot-mic);
            //   - the chat screen's click-to-talk Mic button toggle,
            //     which fires regardless of Screen state because the
            //     user chose it explicitly.
            boolean pttHeld = Keybinds.PUSH_TO_TALK.isDown() && client.screen == null;
            voice.setTransmitting(pttHeld || hotMicOn);
        });

        LOG.info("Shadow Chat initialized");
    }

    // ---------------------------------------------------------------- exposed to UI

    /** Banner line shown at the top of the overlay. May be empty. */
    public String statusLine() { return statusLine; }

    /** Voice subsystem (capture/playback) — used by the overlay for the
     *  "speaking" indicator and PTT hint. May be null very briefly
     *  during startup before {@link #onInitializeClient()} finishes. */
    public VoiceController voice() { return voice; }

    /** Mod-owned saved config (groups, last active channel). */
    public ModConfig modConfig() { return modConfig; }

    /** In-memory UI state (history, presence, active channel). */
    public InputState uiState() { return uiState; }

    /** Launcher-written auth config (token, uuid, name). */
    public AuthConfig authConfig() { return auth; }

    /**
     * Return the host of the currently-joined MC server (e.g. "hypixel.net"),
     * or an empty string if not in multiplayer / on singleplayer. Used by the
     * Discord-style screen to render a meaningful channel name in the
     * sidebar's SERVER row instead of the cryptic "server" key.
     */
    public String currentServerHost() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return "";
        String c = deriveServerChannel(mc);
        if (c == null) return "";
        return c.startsWith("server:") ? c.substring("server:".length()) : c;
    }

    /** True when we've opted in to voice on the current channel. */
    public boolean isInVoice() { return inVoice; }

    /** Whether incoming voice playback is currently muted. */
    public boolean isVoiceMuted() {
        return modConfig.voiceMuted();
    }

    /**
     * Toggle the voice-playback mute. Propagates to VoicePlayback
     * immediately (next 20 ms mixer tick) and persists to
     * shadow-chat-config.json so the choice survives restarts.
     */
    public void toggleVoiceMuted() {
        boolean next = !modConfig.voiceMuted();
        modConfig.setVoiceMuted(next);
        if (voice != null) voice.playback().setMuted(next);
        uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                next ? "Incoming voice muted." : "Incoming voice un-muted."));
    }

    /** True while the chat-screen Mic button is in its on (transmitting) state. */
    public boolean isHotMicOn() { return hotMicOn; }

    /**
     * Toggle the hot-mic state from the chat screen's Mic button. If
     * we're not already opted-in to voice, the toggle opt-ins first
     * so the very first frame actually reaches the relay. Auto-leaves
     * voice is NOT done on toggle-off — the user might still want
     * incoming voice from others.
     */
    public void toggleHotMic() {
        boolean turningOn = !hotMicOn;
        if (turningOn && !inVoice && relay.currentChannel() != null) {
            // Opt-in to voice first; otherwise our frames bounce off
            // the relay's inVoice-receivers gate.
            relay.joinVoice();
            inVoice = true;
            modConfig.setAutoJoinVoice(true);
        }
        hotMicOn = turningOn;
    }

    /**
     * Flip the voice opt-in state for the current connection. Sends
     * {@code voice:join} or {@code voice:leave} depending on direction.
     * Also persists the choice to {@link ModConfig} so we auto-rejoin
     * after a reconnect / channel switch. No-op if not connected —
     * the user gets a system-line nudge so they're not confused by
     * silent failure.
     */
    public void toggleVoiceOptIn() {
        if (relay.currentChannel() == null) {
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.system("Not connected — can't join voice yet"));
            return;
        }
        if (inVoice) {
            relay.leaveVoice();
            inVoice = false;
            modConfig.setAutoJoinVoice(false);
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.system("Left voice"));
        } else {
            relay.joinVoice();
            inVoice = true;
            modConfig.setAutoJoinVoice(true);
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.system("Joined voice — hold V to talk"));
        }
    }

    /**
     * Called by the fullscreen chat screen's "+ Create group" button. Mirrors
     * the {@code /group create} slash command but doesn't require text input —
     * spins up a default-named group with a fresh UUID and switches to it.
     */
    public void createGroupFromUi() {
        String label = "Group " + (modConfig.joinedGroups().size() + 1);
        String id = UUID.randomUUID().toString();
        ModConfig.Group g = new ModConfig.Group(id, label);
        modConfig.addGroup(g);
        uiState.append(uiState.activeChannel(),
                InputState.DisplayLine.system("Created group '" + label
                        + "'. Share this ID to invite: " + id));
        switchChannel("group:" + id);
    }

    /** Look up a display name for a UUID from the active channel's
     *  presence list. Returns the short uuid prefix if not found —
     *  better than rendering a 36-char UUID in the speaker indicator. */
    public String displayNameForUuid(UUID uuid) {
        if (uuid == null) return "?";
        String key = uuid.toString();
        for (Messages.ServerEvent.User u : uiState.presenceFor(uiState.activeChannel())) {
            if (key.equalsIgnoreCase(u.uuid())) return u.name();
        }
        return key.substring(0, 8);
    }

    /**
     * Called by {@link DiscordChatScreen} when the user hits Enter.
     * Splits slash commands off; anything else is a chat message.
     */
    public void submitInput(String raw) {
        String text = raw.trim();
        if (text.isEmpty()) return;

        if (text.startsWith("/")) {
            handleSlashCommand(text);
            return;
        }

        // Plain chat — forward to relay if connected, else explain *why*
        // the message can't be sent so the user can actually fix it.
        if (relay.currentChannel() == null) {
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.error(notConnectedReason()));
            return;
        }

        // Optimistic local echo: show our own message immediately so the
        // send feels instant and is visibly working even if the relay's
        // echo-back is slow, dropped, or the deployed relay is an older
        // build that doesn't fan back to the sender. The relay normally
        // broadcasts to every member including us; when that echo
        // arrives we dedup it against this record (see consumeSelfEcho)
        // so the line never shows twice.
        String selfName = auth.isUsable() ? auth.name() : "me";
        long now = System.currentTimeMillis();
        String echoChannel = uiState.activeChannel();
        uiState.append(echoChannel,
                InputState.DisplayLine.chat(selfName, text, now));
        noteSelfEcho(echoChannel, text);

        relay.sendMessage(text);
    }

    /**
     * Human-readable explanation for why a chat send failed with no
     * open connection. The two common cases are singleplayer (the
     * SERVER channel needs a real multiplayer server) and a relay
     * that hasn't finished connecting yet.
     */
    private String notConnectedReason() {
        if (!auth.isUsable()) {
            return "Not connected — sign in with Microsoft to enable chat.";
        }
        Minecraft mc = Minecraft.getInstance();
        boolean singleplayer = mc != null && (mc.hasSingleplayerServer() || mc.isLocalServer());
        boolean onServerChannel = ModConfig.CHANNEL_SERVER.equals(uiState.activeChannel());
        if (onServerChannel && singleplayer) {
            return "Not connected — server chat needs a multiplayer server. "
                 + "Type /group create <name> to chat anywhere (even singleplayer).";
        }
        return "Not connected — still reaching the relay. Give it a moment, "
             + "or check your internet, then try again.";
    }

    /**
     * Recent self-sent messages awaiting their relay echo, with the
     * channel the optimistic line was shown in and the wall-clock time.
     * Used to dedup the relay's echo-back so our own messages don't
     * render twice. Channel-aware: if the user switches channels
     * between send and echo, the echo lands in a different channel
     * than the optimistic line — consuming it there would EAT a
     * message that was never displayed, so we only match same-channel.
     * Bounded in size + age by {@link #noteSelfEcho}. Single deque of
     * records (not parallel collections) so the pairing can't desync.
     */
    private record SelfEcho(String channel, String text, long atMs) {}
    private final java.util.ArrayDeque<SelfEcho> selfEchoes = new java.util.ArrayDeque<>();

    private void noteSelfEcho(String channel, String text) {
        synchronized (selfEchoes) {
            long now = System.currentTimeMillis();
            selfEchoes.addLast(new SelfEcho(channel, text, now));
            // Drop entries older than 10s or beyond a small cap so a
            // never-arriving echo doesn't leak the queue forever.
            long cutoff = now - 10_000L;
            while (!selfEchoes.isEmpty()
                    && (selfEchoes.peekFirst().atMs() < cutoff || selfEchoes.size() > 32)) {
                selfEchoes.removeFirst();
            }
        }
    }

    /**
     * True (and consumes the matching record) if {@code text} matches a
     * message we just sent ourselves and optimistically displayed in
     * the SAME channel — meaning this is the relay echoing it back and
     * we should drop the duplicate.
     */
    private boolean consumeSelfEcho(String channel, String text) {
        synchronized (selfEchoes) {
            java.util.Iterator<SelfEcho> it = selfEchoes.iterator();
            while (it.hasNext()) {
                SelfEcho e = it.next();
                if (e.text().equals(text)
                        && java.util.Objects.equals(e.channel(), channel)) {
                    it.remove();
                    return true;
                }
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- internals

    private void handleToggleHotkey(Minecraft client) {
        // Two-step semantics so the player gets both halves of "open
        // AND focus" from one keypress, matching the task spec:
        //   1. Make the overlay visible if it wasn't.
        //   2. Open the focused fullscreen chat screen.
        // A second press while focused (Screen is open) is impossible
        // because the keymapping is consumed by the Screen first, so
        // toggling off lives on Esc.
        if (!uiState.isOverlayVisible()) {
            uiState.setOverlayVisible(true);
        }
        // Only push a Screen if one isn't already open — avoid stacking.
        if (client.screen == null) {
            client.setScreen(new DiscordChatScreen(overlay));
        }
    }

    /**
     * Derive a server channel string from the current connection.
     * Returns {@code null} for singleplayer / LAN where there's no
     * meaningful "everyone on this server" cohort.
     */
    private static String deriveServerChannel(Minecraft client) {
        // Singleplayer integrated server doesn't count.
        if (client.hasSingleplayerServer() || client.isLocalServer()) return null;

        ServerData sd = client.getCurrentServer();
        if (sd == null || sd.ip == null || sd.ip.isBlank()) return null;
        if (sd.isLan()) return null;

        String host = sd.ip.trim().toLowerCase(Locale.ROOT);
        // Strip port. Naive split on the last ':' so IPv6 literals
        // would break, but the relay's channel regex doesn't allow
        // colons in the host part anyway — IPv6 servers are vanishingly
        // rare and would need URL-style bracketing to be unambiguous.
        int colon = host.lastIndexOf(':');
        if (colon > 0) host = host.substring(0, colon);
        return "server:" + host;
    }

    /**
     * Open (or switch to) a channel. The {@code channelKey} is what
     * {@link InputState} and {@link ModConfig} use:
     * <ul>
     *   <li>{@code "server"} — the auto-joined server channel.</li>
     *   <li>{@code "group:<uuid>"} — a saved group.</li>
     * </ul>
     */
    public void switchChannel(String channelKey) {
        uiState.setActiveChannel(channelKey);
        modConfig.setActiveChannel(channelKey);
        connectTo(channelKey);
    }

    /**
     * Resolve a channelKey to the wire channel string and open a
     * connection. No-op if not signed in or we can't derive a server
     * channel right now.
     */
    private void connectTo(String channelKey) {
        if (!auth.isUsable()) {
            statusLine = "Not signed in - chat disabled";
            return;
        }

        String wireChannel;
        if (ModConfig.CHANNEL_SERVER.equals(channelKey)) {
            String derived = deriveServerChannel(Minecraft.getInstance());
            if (derived == null) {
                statusLine = "Singleplayer - server chat unavailable";
                try { relay.disconnect(); } catch (Exception ignored) {}
                return;
            }
            wireChannel = derived;
        } else if (channelKey != null && channelKey.startsWith("group:")) {
            wireChannel = channelKey; // already in wire form
        } else {
            statusLine = "Unknown channel: " + channelKey;
            return;
        }

        statusLine = "Connecting to " + wireChannel + "…";
        final String activeChannelKey = channelKey;
        // The relay forgets voice opt-in on socket close — mirror that.
        inVoice = false;
        // Channel changed → drop any decoder state for speakers from
        // the old channel so their voice doesn't bleed in.
        if (voice != null) voice.onChannelChange();
        relay.connect(wireChannel, new RelayClient.EventSink() {
            @Override
            public void onConnected(String ch) {
                runOnClient(() -> {
                    statusLine = "Connected: " + ch;
                    // Blip suppression: if this connect closes a disconnect
                    // gap shorter than PENDING_LEFT_FLUSH_MS, say nothing —
                    // idle-timeout drops + instant reconnects used to spam
                    // "Left server… / Joined server…" pairs at the player.
                    boolean wasBlip = pendingLeftAtMs > 0
                            && System.currentTimeMillis() - pendingLeftAtMs < PENDING_LEFT_FLUSH_MS;
                    pendingLeftAtMs = 0;
                    pendingLeftText = null;
                    if (!wasBlip) {
                        uiState.append(activeChannelKey,
                                InputState.DisplayLine.system("Joined " + ch));
                    }
                    // Re-establish voice opt-in on EVERY (re)connect that
                    // should have it — the relay forgets opt-in when the
                    // socket closes, so a silent blip reconnect would
                    // otherwise leave the mic dead while inVoice still
                    // reads true.
                    if (modConfig.autoJoinVoice() || inVoice) {
                        relay.joinVoice();
                        inVoice = true;
                        if (!wasBlip && modConfig.autoJoinVoice()) {
                            uiState.append(activeChannelKey,
                                    InputState.DisplayLine.system("Auto-rejoined voice"));
                        }
                    }
                });
            }

            @Override
            public void onDisconnected(String ch, String reason) {
                runOnClient(() -> {
                    statusLine = "Disconnected: " + (reason == null ? "" : reason);
                    // Don't append "Left …" yet — park it. If the auto-
                    // reconnect lands within PENDING_LEFT_FLUSH_MS this was
                    // a transient blip and the line is dropped entirely;
                    // tickPendingLeft() flushes it once if the outage is
                    // real. Repeated failures just refresh the SAME pending
                    // line instead of appending one per retry.
                    pendingLeftText = "Left " + ch
                            + (reason == null || reason.isBlank() ? "" : " (" + reason + ")");
                    pendingLeftChannelKey = activeChannelKey;
                    if (pendingLeftAtMs == 0) {
                        pendingLeftAtMs = System.currentTimeMillis();
                    }
                });
            }

            @Override
            public void onEvent(Messages.ServerEvent event) {
                runOnClient(() -> {
                    if (event instanceof Messages.ServerEvent.ChatMessage cm) {
                        boolean isSelf = auth.isUsable()
                                && cm.fromUuid() != null
                                && cm.fromUuid().equalsIgnoreCase(auth.uuid());
                        // If this is the relay echoing back a message we
                        // already showed optimistically on send, drop the
                        // duplicate. consumeSelfEcho only matches messages
                        // we actually sent ourselves (gated on isSelf), so
                        // someone else sending identical text still shows.
                        if (isSelf && consumeSelfEcho(activeChannelKey, cm.text())) {
                            return;
                        }
                        uiState.append(activeChannelKey,
                                InputState.DisplayLine.chat(cm.name(), cm.text(), cm.ts()));
                        // Bump unread count unless the user is reading this
                        // channel right now (it's the active channel AND the
                        // fullscreen chat screen is open). Messages landing
                        // on the active channel while the screen is closed
                        // feed the NEW-messages divider shown on next open.
                        // Skip our own echoed messages so the badge doesn't
                        // light up immediately after we sent something.
                        if (!isSelf) {
                            boolean reading = Minecraft.getInstance().screen
                                    instanceof DiscordChatScreen;
                            uiState.incrementUnread(activeChannelKey, reading);
                        }
                    } else if (event instanceof Messages.ServerEvent.Presence p) {
                        uiState.setPresence(activeChannelKey, p.users());
                    } else if (event instanceof Messages.ServerEvent.ErrorMsg em) {
                        uiState.append(activeChannelKey,
                                InputState.DisplayLine.error(em.message()));
                    } else if (event instanceof Messages.ServerEvent.VoiceRoster vr) {
                        uiState.setVoiceRoster(activeChannelKey, vr.members());
                    }
                    // Unknown events: silently dropped (forward-compat).
                });
            }

            @Override
            public void onVoice(UUID sender, byte[] opus) {
                // Voice frames are hot-path; skip the client-thread
                // bounce and hand straight to the mixer (which runs on
                // its own thread). UI side reads currentSpeakers()
                // from render code which already hops to the right
                // thread.
                if (voice != null) voice.onVoiceFrame(sender, opus);
            }
        });
    }

    /**
     * Bounce a runnable onto the Minecraft client thread. All our
     * callbacks from the relay arrive on the HTTP executor pool, and
     * touching UI state from off-thread is asking for racy renders
     * and the occasional ConcurrentModificationException.
     */
    private static void runOnClient(Runnable r) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) { r.run(); return; }
        mc.execute(r);
    }

    /** How long a disconnect must persist before the "Left …" line is
     *  shown. Reconnects inside this window are silent blips. */
    private static final long PENDING_LEFT_FLUSH_MS = 5_000;
    /** Parked "Left …" line awaiting flush-or-drop. 0 = none pending. */
    private volatile long pendingLeftAtMs = 0;
    private volatile String pendingLeftText = null;
    private volatile String pendingLeftChannelKey = null;

    /**
     * Flush a parked "Left …" line once the disconnect has outlived the
     * blip window. Runs on the client tick, so the append happens on
     * the right thread. One line per outage no matter how many retry
     * failures refresh the text.
     */
    private void tickPendingLeft() {
        if (pendingLeftAtMs == 0) return;
        if (System.currentTimeMillis() - pendingLeftAtMs < PENDING_LEFT_FLUSH_MS) return;
        String text = pendingLeftText;
        String ch = pendingLeftChannelKey;
        pendingLeftAtMs = 0;
        pendingLeftText = null;
        pendingLeftChannelKey = null;
        if (text != null && ch != null) {
            uiState.append(ch, InputState.DisplayLine.system(text));
        }
    }

    /** Tick countdown to auto-open chat on world load. -1 = inactive. */
    private volatile int autoOpenChatCountdown = -1;

    /** Arm the auto-open countdown — fires once after the given tick delay. */
    private void scheduleAutoOpenChat(int ticks) {
        autoOpenChatCountdown = Math.max(1, ticks);
    }

    /**
     * Drive the "Reconnecting in Ns…" countdown shown in the status
     * line while RelayClient is between attempts. We only overwrite
     * the status when there's actually no live connection and the
     * relay has a pending reconnect — otherwise other status updates
     * (Signed in, Connecting…) take precedence.
     */
    private void tickReconnectCountdown() {
        if (relay == null) return;
        long nextAt = relay.nextReconnectAtMs();
        if (nextAt <= 0) return;
        if (relay.currentChannel() != null) return; // we're actually connected
        long secsLeft = Math.max(0, (nextAt - System.currentTimeMillis() + 500) / 1000);
        statusLine = secsLeft > 0
                ? "Reconnecting in " + secsLeft + "s…"
                : "Reconnecting…";
    }

    /** Called from the client-tick handler to drive the countdown. */
    private void tickAutoOpenChat(Minecraft client) {
        if (autoOpenChatCountdown < 0) return;
        if (--autoOpenChatCountdown > 0) return;
        autoOpenChatCountdown = -1;
        // Same guards as the IPC command path — don't preempt a
        // different Screen the user already has open, and bail if the
        // player isn't actually loaded in.
        if (client == null || client.player == null || client.screen != null) return;
        uiState.setOverlayVisible(true);
        client.setScreen(new app.shadowclient.chat.ui.DiscordChatScreen(overlay));
    }

    /** Ticks until the next auth-file re-read. ~5 min at 20 TPS. */
    private int authReloadTicks = 20 * 60 * 5;

    /**
     * Periodically re-read shadow-chat-auth.json so a rotated Microsoft
     * token gets picked up WITHOUT restarting the game. The relay verifies
     * the token and 401s once it expires (~24h), so an all-day grind or an
     * AFK farm would otherwise lose chat the moment the socket dropped and
     * retried with a dead token. The launcher (run.bat / Tauri) rewrites
     * the file with a fresh token every ~20-30 min; this is the runtime
     * half that makes that refresh actually reach the live mod.
     */
    private void tickAuthReload() {
        if (--authReloadTicks > 0) return;
        authReloadTicks = 20 * 60 * 5; // re-arm: 5 minutes
        maybeReloadAuth();
    }

    /**
     * Re-read the auth file and hot-swap the token if it changed. Cheap
     * (~1 KB read every 5 min) and only acts when the token actually
     * rotated (≈ once a day). Reconnects a live socket so it rides the
     * fresh token — and so the very next reconnect-after-a-drop uses a
     * valid one. Best-effort: a missing / half-written / offline file
     * leaves the current auth untouched.
     */
    private void maybeReloadAuth() {
        AuthConfig fresh;
        try {
            fresh = AuthConfig.load();
        } catch (Exception e) {
            return; // file mid-write or IO blip — try again next cycle
        }
        if (fresh == null || !fresh.isUsable()) return;
        String oldToken = (auth == null) ? null : auth.token();
        if (fresh.token() != null && fresh.token().equals(oldToken)) return; // unchanged

        LOG.info("Shadow Chat: auth token rotated on disk — hot-swapping (no restart needed)");
        this.auth = fresh;
        relay.setAuth(fresh);
        statusLine = "Signed in as " + fresh.name();
        // If we hold a live channel, reconnect so the relay re-verifies
        // against the fresh token immediately. connectTo() no-ops safely
        // in singleplayer / when there's no meaningful channel.
        if (relay.currentChannel() != null) {
            connectTo(uiState.activeChannel());
        }
    }

    // ---------------------------------------------------------------- slash commands

    /**
     * Slash commands handled entirely on the client.
     * <ul>
     *   <li>{@code /help} — print this list.</li>
     *   <li>{@code /group create <label>} — new group with random UUID; switches to it.</li>
     *   <li>{@code /group join <uuid>} — save and switch to an existing group.</li>
     *   <li>{@code /group leave} — leave the currently-active group.</li>
     *   <li>{@code /voice join} / {@code /voice leave} — toggle voice opt-in via keyboard.</li>
     *   <li>{@code /coords} — send your X/Y/Z to the active channel.</li>
     *   <li>{@code /whoami} — print uuid + name (debug aid).</li>
     * </ul>
     */
    private void handleSlashCommand(String line) {
        String[] parts = line.split("\\s+");
        if (parts.length == 0) return;
        // Minigame helpers (speed HUD, lap timer, ice highlighter,
        // auto-sprint, auto-respawn) all live behind their own slash
        // commands — let the dispatcher claim them before falling
        // through to the chat-mod's own commands.
        if (MinigameCommands.dispatch(parts, dl ->
                uiState.append(uiState.activeChannel(), dl))) {
            return;
        }
        // QoL helpers — recipe preview, coords HUD, held-item HUD.
        if (QolCommands.dispatch(parts, dl ->
                uiState.append(uiState.activeChannel(), dl))) {
            return;
        }
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "/help" -> printHelp();
            case "/group" -> handleGroupCommand(parts, line);
            case "/voice" -> handleVoiceCommand(parts);
            case "/auto-open-chat" -> handleAutoOpenChatCommand(parts);
            case "/whoami" -> {
                String msg = auth.isUsable()
                        ? auth.name() + " (" + auth.uuid() + ")"
                        : "not signed in";
                uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(msg));
            }
            case "/coords" -> handleCoordsCommand();
            default -> uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.error("Unknown command: " + parts[0] + " — try /help"));
        }
    }

    private void printHelp() {
        // Decorate each line with the current state when one applies —
        // /help doubles as a status read-out so the user doesn't have
        // to remember whether they previously toggled something on.
        String activeChannel = uiState.activeChannel();
        String activeChannelDesc;
        if (ModConfig.CHANNEL_SERVER.equals(activeChannel)) {
            String host = currentServerHost();
            activeChannelDesc = host.isEmpty() ? "the server channel" : "server: " + host;
        } else if (activeChannel != null && activeChannel.startsWith("group:")) {
            String id = activeChannel.substring("group:".length());
            ModConfig.Group g = modConfig.findGroup(id);
            String name = g != null && g.name != null && !g.name.isBlank() ? g.name : id;
            activeChannelDesc = "group: " + name;
        } else {
            activeChannelDesc = activeChannel == null ? "none" : activeChannel;
        }
        String voiceMutedDesc = modConfig.voiceMuted() ? "yes" : "no";
        String autoOpenDesc = modConfig.autoOpenChatOnJoin() ? "ON" : "off";
        String voiceStateDesc = inVoice ? "joined" : "not joined";
        String autoJoinDesc = modConfig.autoJoinVoice() ? "ON" : "off";

        String[] header = {
                "Shadow Chat — current state and commands:",
                "Active channel:      " + activeChannelDesc,
                "Voice opt-in:        " + voiceStateDesc + " (auto-rejoin " + autoJoinDesc + ")",
                "Voice playback:      " + (modConfig.voiceMuted() ? "MUTED" : "audible"),
                "Auto-open on join:   " + autoOpenDesc,
                "",
                "Slash commands:",
                "/group create <label> — make a private group; share the ID it prints",
                "/group join <uuid>    — join an existing group",
                "/group leave          — leave the current group",
                "/voice join | leave   — opt in / out of voice (currently " + voiceStateDesc + ")",
                "/auto-open-chat on|off|status — pop the chat screen open every world join"
                        + " (currently " + autoOpenDesc + ")",
                "/coords               — paste your X/Y/Z into chat",
                "/whoami               — show your UUID and display name",
                "/help                 — show this list",
                "",
                "Minigame helpers (session-scoped toggles):",
        };
        for (String l : header) {
            uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(l));
        }
        for (String l : MinigameCommands.helpLines()) {
            uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(l));
        }
        uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(""));
        uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                "Client QoL helpers:"));
        for (String l : QolCommands.helpLines()) {
            uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(l));
        }
        uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(""));
        uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                "(Mute incoming voice currently: " + voiceMutedDesc
                        + " — toggle from the settings * in the user bar.)"));
    }

    private void handleAutoOpenChatCommand(String[] parts) {
        if (parts.length < 2 || "status".equalsIgnoreCase(parts[1])) {
            uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                    "Auto-open-chat-on-join is " + (modConfig.autoOpenChatOnJoin() ? "ON" : "OFF")));
            return;
        }
        String sub = parts[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "on", "true", "enable" -> {
                modConfig.setAutoOpenChatOnJoin(true);
                uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                        "Chat will now open automatically when you join a multiplayer world."));
            }
            case "off", "false", "disable" -> {
                modConfig.setAutoOpenChatOnJoin(false);
                uiState.append(uiState.activeChannel(), InputState.DisplayLine.system(
                        "Auto-open disabled. Press ; to open chat manually."));
            }
            default -> uiState.append(uiState.activeChannel(), InputState.DisplayLine.error(
                    "Unknown /auto-open-chat subcommand: " + parts[1]));
        }
    }

    private void handleVoiceCommand(String[] parts) {
        if (parts.length < 2) {
            uiState.append(uiState.activeChannel(), InputState.DisplayLine.error(
                    "Usage: /voice join | /voice leave"));
            return;
        }
        String sub = parts[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "join" -> { if (!inVoice) toggleVoiceOptIn(); }
            case "leave" -> { if (inVoice) toggleVoiceOptIn(); }
            default -> uiState.append(uiState.activeChannel(), InputState.DisplayLine.error(
                    "Unknown /voice subcommand: " + parts[1]));
        }
    }

    /**
     * Send the player's current X/Y/Z to the active channel as a chat
     * message. Triggered by typing {@code /coords} (keyboard) or by
     * clicking the Coords chip in the input row (mouse, since v0.1.3).
     */
    private void handleCoordsCommand() {
        var coords = app.shadowclient.chat.cmd.CoordsHelper.currentCoords();
        if (coords.isEmpty()) {
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.error("No player loaded — /coords only works in-world."));
            return;
        }
        // If we're not connected to a channel, echo locally so the
        // user at least sees the format. Otherwise send for real.
        if (relay.currentChannel() == null) {
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.system("(would send) " + coords.get()));
            return;
        }
        relay.sendMessage(coords.get());
    }

    private void handleGroupCommand(String[] parts, String fullLine) {
        if (parts.length < 2) {
            uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.error("Usage: /group create <label> | /group join <uuid> | /group leave"));
            return;
        }
        String sub = parts[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> {
                // Label is everything after "/group create "
                String label;
                if (parts.length >= 3) {
                    int idx = fullLine.indexOf(parts[1]) + parts[1].length();
                    label = fullLine.substring(idx).trim();
                    if (label.isEmpty()) label = "Untitled group";
                } else {
                    label = "Group " + (modConfig.joinedGroups().size() + 1);
                }
                String id = UUID.randomUUID().toString();
                ModConfig.Group g = new ModConfig.Group(id, label);
                modConfig.addGroup(g);
                uiState.append(uiState.activeChannel(),
                        InputState.DisplayLine.system("Created group '" + label
                                + "'. Share this ID to invite: " + id));
                switchChannel("group:" + id);
            }
            case "join" -> {
                if (parts.length < 3 || parts[2].isBlank()) {
                    uiState.append(uiState.activeChannel(),
                            InputState.DisplayLine.error("Usage: /group join <uuid>"));
                    return;
                }
                String id = parts[2].trim();
                // Best-effort uuid sanity check — we don't reject if it
                // doesn't parse because the relay's channel regex is the
                // ultimate authority, but warn the user.
                try { UUID.fromString(id); } catch (IllegalArgumentException ex) {
                    uiState.append(uiState.activeChannel(),
                            InputState.DisplayLine.error("That doesn't look like a group ID, but trying anyway…"));
                }
                modConfig.addGroup(new ModConfig.Group(id, "Group " + (modConfig.joinedGroups().size() + 1)));
                switchChannel("group:" + id);
            }
            case "leave" -> {
                String active = uiState.activeChannel();
                if (active == null || !active.startsWith("group:")) {
                    uiState.append(uiState.activeChannel(),
                            InputState.DisplayLine.error("Not in a group right now"));
                    return;
                }
                String id = active.substring("group:".length());
                modConfig.removeGroup(id);
                uiState.clear(active);
                uiState.append(ModConfig.CHANNEL_SERVER,
                        InputState.DisplayLine.system("Left group " + id));
                switchChannel(ModConfig.CHANNEL_SERVER);
            }
            default -> uiState.append(uiState.activeChannel(),
                    InputState.DisplayLine.error("Unknown /group subcommand: " + parts[1]));
        }
    }
}
