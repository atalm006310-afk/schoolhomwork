package app.shadowclient.chat.ui;

import app.shadowclient.chat.ShadowChatClient;
import app.shadowclient.chat.cmd.CoordsHelper;
import app.shadowclient.chat.config.AuthConfig;
import app.shadowclient.chat.config.ModConfig;
import app.shadowclient.chat.relay.Messages.ServerEvent;
import app.shadowclient.chat.voice.VoiceController;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.PlayerSkin;
import org.lwjgl.glfw.GLFW;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Fullscreen Discord-style chat screen.
 *
 * <p>Takes over the whole MC window when the user opens chat: a left
 * server rail, a channel/voice sidebar, and a main message area with an
 * input pill at the bottom. Click a channel row to switch, click
 * "+ Create group" to spawn one, click "Coords" to paste the player's
 * X/Y/Z into the buffer.
 *
 * <p>The HUD-mode {@link ChatOverlay} is suppressed while this screen
 * is open ({@code onRender} checks {@code mc.screen instanceof DiscordChatScreen}).
 *
 * <h2>1.21.11 API note</h2>
 * Uses {@link KeyEvent} / {@link CharacterEvent} / {@link MouseButtonEvent}
 * record forms — the older {@code (int,int,int)} signatures were removed.
 */
public final class DiscordChatScreen extends Screen {

    // ---- Layout (GUI-scaled px) ----
    private static final int SERVER_RAIL_W = 56;
    private static final int SIDEBAR_W = 220;
    private static final int HEADER_H = 36;
    private static final int INPUT_H = 36;
    private static final int USERBAR_H = 48;
    private static final int CHAN_ROW_H = 20;
    private static final int CATEGORY_H = 18;
    private static final int PILL_SIZE = 44;

    // ---- Colors (ARGB) ----
    // Sourced from the launcher's CSS palette so the in-game chat
    // matches the launcher's dark theme. --bg = 0x0a0c12, --bg-2 = 0x141821,
    // --bg-3 = 0x1c2230, --line = 0x2a2f3d, --text = 0xecedf2.
    private static final int FILM = 0xE0000000;
    private static final int SERVER_RAIL_BG = 0xFF0A0C12;
    private static final int SIDEBAR_BG = 0xFF141821;
    private static final int MAIN_BG = 0xFF0E1119;
    private static final int HEADER_BG = 0xFF141821;
    private static final int INPUT_BG = 0xFF141821;
    private static final int CHIP_ACTIVE = 0xFF1C2230;
    private static final int CHIP_HOVER = 0xFF181C25;
    private static final int TEXT_DIM = 0xFF8A8C98;
    private static final int TEXT = 0xFFB4B6BF;
    private static final int TEXT_BRIGHT = 0xFFECEDF2;
    private static final int ACCENT = 0xFF7AA8E0;
    private static final int RED_PILL = 0xFFEC4747;
    private static final int GREEN = 0xFF22DD55;
    private static final int DIVIDER = 0xFF2A2F3D;
    private static final int COORDS_HIGHLIGHT = 0x402D5A8C;

    // Stable colors keyed off speaker-name hash so different people stand out.
    private static final int[] NAME_COLORS = {
            0xFFFF6B6B, 0xFFFFA94D, 0xFFFFD43B, 0xFFA9E34B,
            0xFF63E6BE, 0xFF4DABF7, 0xFFB197FC, 0xFFE599F7,
    };

    private static final DateTimeFormatter HHMMSS =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    private static final int MAX_INPUT = 512;

    private final ChatOverlay overlayLegacy; // unused — kept to preserve old signature compat
    private final StringBuilder buffer = new StringBuilder();
    /**
     * Caret position within {@link #buffer}, measured in chars in
     * [0, buffer.length()]. Insert / backspace / DELETE all act here,
     * not at the end. Clamped by {@link #clampCaret()} after every edit.
     */
    private int caret = 0;

    /**
     * Sent-message ring (newest last), shared across screen instances so
     * recall survives the screen closing on send — each open is a fresh
     * {@code new DiscordChatScreen(...)}, so a per-instance list would
     * forget everything the moment Enter fires. Capped at
     * {@link #HISTORY_MAX}; the Enter handler pushes the sent text before
     * clearing the buffer.
     */
    private static final int HISTORY_MAX = 30;
    private static final java.util.ArrayDeque<String> SENT_HISTORY = new java.util.ArrayDeque<>();
    /**
     * Terminal-style recall cursor. -1 = editing the live draft (nothing
     * recalled); 0 = newest sent line, increasing toward older. UP walks
     * back, DOWN walks forward and at -1 restores {@link #liveDraft}.
     * Reset to -1 on screen open (constructor).
     */
    private int historyIndex = -1;
    /** The in-progress draft stashed when the user first presses UP, so
     *  DOWN past the newest history entry restores it verbatim. */
    private String liveDraft = "";

    /** Hit-test rectangle for a clickable channel row. */
    private record ChannelHit(int x1, int y1, int x2, int y2, String channelKey) {}

    private final List<ChannelHit> channelHits = new ArrayList<>();
    private int coordsBtnX1, coordsBtnY1, coordsBtnX2, coordsBtnY2;
    private int createGroupX1, createGroupY1, createGroupX2, createGroupY2;
    private int voiceToggleX1, voiceToggleY1, voiceToggleX2, voiceToggleY2;
    private int copyIdBtnX1, copyIdBtnY1, copyIdBtnX2, copyIdBtnY2;
    private int micBtnX1, micBtnY1, micBtnX2, micBtnY2;
    /** Set when the Copy ID button was clicked — paints "Copied!" for ~1s. */
    private long copiedFlashUntil = 0;
    /**
     * How many log rows back from the newest the log is scrolled.
     * Rows include the synthetic day-separator / NEW-divider rows, so
     * one wheel notch covers the same visual distance everywhere.
     * Zero means "stuck to the bottom showing the latest". Bumped by
     * mouse wheel up; clamped against the row count on render.
     */
    private int scrollOffset = 0;
    /** Channel the scroll offset is currently anchored to — reset when it changes. */
    private String scrollAnchorChannel = null;
    /**
     * Unread count for the active channel captured ONCE when this screen
     * was constructed — anchors the NEW-messages divider. The live unread
     * counter is cleared right after capture (opening the screen means
     * the user is now reading), so this is the only memory of where
     * "new" starts.
     */
    private final int unreadAtOpen;
    /**
     * The first unread message at open — the exact line instance at index
     * (size - unreadAtOpen) in the active channel's log when the screen
     * opened. The NEW divider renders immediately above it and stays
     * pinned there while the screen is open: new arrivals append after
     * it, and the identity match in {@link #buildLogRows} keeps the
     * anchor put (and silently drops the divider if the line is ever
     * evicted). Null when unreadAtOpen == 0.
     */
    private final InputState.DisplayLine firstUnreadAtOpen;
    /**
     * When true the main area renders the Voice Room grid instead of
     * the text-channel message log. Toggled by a clickable entry under
     * the sidebar's VOICE category; preserved across renders but reset
     * to false on every channel switch so the user lands on text by
     * default in the new channel.
     */
    private boolean viewingVoiceRoom = false;
    private int voiceRoomBtnX1, voiceRoomBtnY1, voiceRoomBtnX2, voiceRoomBtnY2;
    /** When true the main area renders the settings panel. Mutually
     *  exclusive with viewingVoiceRoom — opening one closes the other. */
    private boolean viewingSettings = false;
    /** Pixels the settings panel is scrolled down. 0 = top. The panel
     *  outgrew one screen once the QoL + minigame toggle sections landed
     *  (11 rows), so it scrolls like the message log does. */
    private int settingsScrollOffset = 0;
    /** Content height measured during the last settings render — used to
     *  clamp {@link #settingsScrollOffset} (self-correcting one frame
     *  after a resize). */
    private int settingsContentHeight = 0;
    /** Visible band of the settings scroll viewport in the last render;
     *  drawToggleRow only registers hit-rects for chips inside it so
     *  scrolled-away toggles aren't invisibly clickable. */
    private int settingsViewTop = 0, settingsViewBottom = 0;
    private int settingsBtnX1, settingsBtnY1, settingsBtnX2, settingsBtnY2;
    private int muteBtnX1, muteBtnY1, muteBtnX2, muteBtnY2;
    /** Inline "Join voice" button on the voice-room empty state. */
    private int emptyJoinBtnX1, emptyJoinBtnY1, emptyJoinBtnX2, emptyJoinBtnY2;
    /** One hit-rect per coords-share line in the current render. */
    private record CoordsHit(int x1, int y1, int x2, int y2, String text) {}
    private final List<CoordsHit> coordsHits = new ArrayList<>();
    /** Timestamp until which we paint a "Copied" badge over the
     *  last-clicked coords line (ms since epoch). */
    private long coordsCopiedUntil = 0;
    /** Bounds of the line the user just copied, for the "Copied" badge. */
    private int copiedLineX1, copiedLineY1, copiedLineX2, copiedLineY2;
    /** Per-toggle hit-rects inside the settings panel. Cleared each
     *  render and repopulated by drawSettings. */
    private final List<ToggleHit> settingsToggleHits = new ArrayList<>();
    private record ToggleHit(int x1, int y1, int x2, int y2, String key) {}

    public DiscordChatScreen(ChatOverlay legacyOverlay) {
        super(Component.literal("Shadow Chat"));
        this.overlayLegacy = legacyOverlay;
        // Capture the active channel's unread count ONCE at open and pin
        // the NEW divider to the first unread line (index size - unread).
        // Captured here rather than init() so window resizes (which
        // re-run init) can't re-anchor or drop the marker mid-session.
        InputState st = ShadowChatClient.get().uiState();
        String ch = st.activeChannel();
        this.unreadAtOpen = st.unreadFor(ch);
        InputState.DisplayLine anchor = null;
        if (unreadAtOpen > 0) {
            List<InputState.DisplayLine> lines = st.linesFor(ch);
            int idx = Math.max(0, lines.size() - unreadAtOpen);
            if (idx < lines.size()) anchor = lines.get(idx);
        }
        this.firstUnreadAtOpen = anchor;
        // The user is reading this channel now — clear its unread badge.
        // (Capture above happened first; the channel-switch clear via
        // setActiveChannel keeps working independently of this.)
        st.clearUnread(ch);
        // Fresh open → start in the live draft, not mid-recall. (The
        // shared SENT_HISTORY itself persists; only this per-open cursor
        // resets.)
        this.historyIndex = -1;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ============================================================ render

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Dim the world behind. We don't call super.render() because the
        // default Screen renderer paints either a vanilla dirt background
        // (when no level) or its own dim which fights with our colors.
        gfx.fill(0, 0, this.width, this.height, FILM);

        channelHits.clear();
        coordsBtnX2 = 0;
        createGroupX2 = 0;
        voiceToggleX2 = 0;
        copyIdBtnX2 = 0;
        micBtnX2 = 0;
        voiceRoomBtnX2 = 0;
        settingsBtnX2 = 0;
        muteBtnX2 = 0;
        settingsToggleHits.clear();
        emptyJoinBtnX2 = 0;
        coordsHits.clear();

        drawServerRail(gfx, 0, 0, SERVER_RAIL_W, this.height);
        drawSidebar(gfx, SERVER_RAIL_W, 0, SIDEBAR_W, this.height, mouseX, mouseY);

        int mainX = SERVER_RAIL_W + SIDEBAR_W;
        drawMain(gfx, mainX, 0, this.width - mainX, this.height, mouseX, mouseY);
    }

    // ------------------------------------------------------ server rail

    private void drawServerRail(GuiGraphics gfx, int x, int y, int w, int h) {
        gfx.fill(x, y, x + w, y + h, SERVER_RAIL_BG);
        int pillX = x + (w - PILL_SIZE) / 2;
        int pillY = y + 14;
        // Active-channel indicator strip (left edge).
        gfx.fill(x, pillY + 6, x + 3, pillY + PILL_SIZE - 6, TEXT_BRIGHT);
        // Red "S" pill — Shadow Client brand badge.
        gfx.fill(pillX, pillY, pillX + PILL_SIZE, pillY + PILL_SIZE, RED_PILL);
        String letter = "S";
        int lw = this.font.width(letter);
        gfx.drawString(this.font, letter,
                pillX + (PILL_SIZE - lw) / 2,
                pillY + (PILL_SIZE - this.font.lineHeight) / 2 + 1,
                TEXT_BRIGHT, false);
    }

    // ------------------------------------------------------ sidebar

    private void drawSidebar(GuiGraphics gfx, int x, int y, int w, int h, int mouseX, int mouseY) {
        gfx.fill(x, y, x + w, y + h, SIDEBAR_BG);

        ShadowChatClient sc = ShadowChatClient.get();
        InputState st = sc.uiState();
        ModConfig cfg = sc.modConfig();

        // -- branding header --
        int rowY = y + 12;
        gfx.drawString(this.font, "SHADOW CHAT",
                x + 12, rowY, TEXT_BRIGHT, false);
        rowY += this.font.lineHeight + 6;
        gfx.fill(x + 10, rowY, x + w - 10, rowY + 1, DIVIDER);
        rowY += 10;

        String activeChannel = st.activeChannel();

        // -- SERVER --
        rowY = drawCategoryLabel(gfx, x, rowY, "SERVER");
        String serverLabel = sc.currentServerHost();
        boolean serverOk = !serverLabel.isEmpty();
        String displayedServer = serverOk ? serverLabel : "(not connected)";
        rowY = drawChannelRow(gfx, x, rowY, w, "# " + displayedServer,
                serverOk ? ModConfig.CHANNEL_SERVER : null,
                ModConfig.CHANNEL_SERVER.equals(activeChannel),
                mouseX, mouseY, st.unreadFor(ModConfig.CHANNEL_SERVER), serverOk);
        rowY += 6;

        // -- GROUPS --
        rowY = drawCategoryLabel(gfx, x, rowY, "GROUPS");
        for (ModConfig.Group g : new ArrayList<>(cfg.joinedGroups())) {
            String key = "group:" + g.id;
            String name = (g.name == null || g.name.isBlank()) ? shortId(g.id) : g.name;
            rowY = drawChannelRow(gfx, x, rowY, w, "# " + name, key,
                    key.equals(activeChannel), mouseX, mouseY,
                    st.unreadFor(key), true);
        }
        rowY = drawCreateGroupRow(gfx, x, rowY, w, mouseX, mouseY);
        rowY += 6;

        // -- VOICE --
        rowY = drawCategoryLabel(gfx, x, rowY, "VOICE");
        VoiceController vc = sc.voice();
        List<UUID> speakers = (vc != null) ? vc.playback().currentSpeakers() : List.of();
        int rosterSize = st.voiceRosterFor(activeChannel).size();
        rowY = drawVoiceToggleRow(gfx, x, rowY, w, sc.isInVoice(), rosterSize,
                mouseX, mouseY);
        // "Voice Room" tab — flips the main area to a participant
        // grid view (faces + speaking rings) instead of the text log.
        rowY = drawVoiceRoomRow(gfx, x, rowY, w, mouseX, mouseY, rosterSize);
        for (UUID id : speakers) {
            String name = sc.displayNameForUuid(id);
            rowY = drawSpeakerRow(gfx, x, rowY, w, id, name);
        }

        // -- user info bar pinned to bottom --
        drawUserBar(gfx, x, y + h - USERBAR_H, w, USERBAR_H);
    }

    private int drawCategoryLabel(GuiGraphics gfx, int x, int y, String label) {
        gfx.drawString(this.font, label, x + 12, y + 4, TEXT_DIM, false);
        return y + CATEGORY_H;
    }

    /**
     * Draw a channel row with optional highlight (active) / hover / unread badge.
     * Returns y-after-row so callers can stack rows.
     *
     * @param channelKey  if non-null, registers a click hit-test for switching
     * @param unreadBadge unread message count; rendered as a red pill on the right when > 0
     * @param enabled     when false, the row is dimmed and not clickable
     */
    private int drawChannelRow(GuiGraphics gfx, int x, int y, int w, String label,
                               String channelKey, boolean active,
                               int mouseX, int mouseY, int unreadBadge, boolean enabled) {
        int rowX = x + 6;
        int rowW = w - 12;
        boolean hover = enabled && channelKey != null
                && mouseX >= rowX && mouseX <= rowX + rowW
                && mouseY >= y && mouseY <= y + CHAN_ROW_H;
        int bg = active ? CHIP_ACTIVE : (hover ? CHIP_HOVER : 0);
        if (bg != 0) gfx.fill(rowX, y, rowX + rowW, y + CHAN_ROW_H, bg);
        // Rows with unread messages get brighter label text so the eye
        // catches them even before the pill registers.
        int color = !enabled ? TEXT_DIM
                : (active ? TEXT_BRIGHT
                : (unreadBadge > 0 ? TEXT_BRIGHT : TEXT));
        gfx.drawString(this.font, label,
                rowX + 8, y + (CHAN_ROW_H - this.font.lineHeight) / 2 + 1,
                color, false);
        if (unreadBadge > 0) {
            String txt = unreadBadge >= 99 ? "99+" : String.valueOf(unreadBadge);
            int tw = this.font.width(txt) + 8;
            int badgeX = rowX + rowW - tw - 4;
            gfx.fill(badgeX, y + 4, badgeX + tw, y + CHAN_ROW_H - 4, RED_PILL);
            gfx.drawString(this.font, txt,
                    badgeX + 4, y + (CHAN_ROW_H - this.font.lineHeight) / 2 + 1,
                    TEXT_BRIGHT, false);
        }
        if (channelKey != null && enabled) {
            channelHits.add(new ChannelHit(rowX, y, rowX + rowW, y + CHAN_ROW_H, channelKey));
        }
        return y + CHAN_ROW_H;
    }

    private int drawCreateGroupRow(GuiGraphics gfx, int x, int y, int w, int mouseX, int mouseY) {
        int rowX = x + 6;
        int rowW = w - 12;
        boolean hover = mouseX >= rowX && mouseX <= rowX + rowW
                && mouseY >= y && mouseY <= y + CHAN_ROW_H;
        if (hover) gfx.fill(rowX, y, rowX + rowW, y + CHAN_ROW_H, CHIP_HOVER);
        gfx.drawString(this.font, "+ Create group",
                rowX + 8, y + (CHAN_ROW_H - this.font.lineHeight) / 2 + 1,
                hover ? TEXT_BRIGHT : TEXT_DIM, false);
        createGroupX1 = rowX; createGroupY1 = y;
        createGroupX2 = rowX + rowW; createGroupY2 = y + CHAN_ROW_H;
        return y + CHAN_ROW_H;
    }

    /**
     * Render the "Voice Room" view-toggle row in the sidebar. Clicking
     * flips {@link #viewingVoiceRoom}; the main area then renders the
     * participant grid instead of the text-channel log.
     */
    private int drawVoiceRoomRow(GuiGraphics gfx, int x, int y, int w,
                                 int mouseX, int mouseY, int rosterSize) {
        int rowX = x + 6;
        int rowW = w - 12;
        boolean active = viewingVoiceRoom;
        boolean hover = mouseX >= rowX && mouseX <= rowX + rowW
                && mouseY >= y && mouseY <= y + CHAN_ROW_H;
        int bg = active ? CHIP_ACTIVE : (hover ? CHIP_HOVER : 0);
        if (bg != 0) gfx.fill(rowX, y, rowX + rowW, y + CHAN_ROW_H, bg);
        String label = "# Voice Room";
        if (rosterSize > 0) label = label + "  " + rosterSize;
        int color = active ? TEXT_BRIGHT : TEXT;
        gfx.drawString(this.font, label,
                rowX + 8, y + (CHAN_ROW_H - this.font.lineHeight) / 2 + 1,
                color, false);
        voiceRoomBtnX1 = rowX; voiceRoomBtnY1 = y;
        voiceRoomBtnX2 = rowX + rowW; voiceRoomBtnY2 = y + CHAN_ROW_H;
        return y + CHAN_ROW_H;
    }

    /**
     * Render the Join/Leave Voice button. When opted-in we paint it
     * green-ish; when out we paint it dim. Click hit-tested in
     * {@link #mouseClicked}.
     */
    private int drawVoiceToggleRow(GuiGraphics gfx, int x, int y, int w,
                                   boolean inVoice, int rosterSize,
                                   int mouseX, int mouseY) {
        int rowX = x + 6;
        int rowW = w - 12;
        int btnH = CHAN_ROW_H + 4;
        boolean hover = mouseX >= rowX && mouseX <= rowX + rowW
                && mouseY >= y && mouseY <= y + btnH;
        int bg = inVoice
                ? (hover ? 0xFFC23A3A : RED_PILL)
                : (hover ? 0xFF3C8C46 : 0xFF2A6638);
        gfx.fill(rowX, y, rowX + rowW, y + btnH, bg);
        String label = inVoice ? "Leave voice" : "Join voice";
        if (rosterSize > 0) label = label + "  (" + rosterSize + " in)";
        gfx.drawString(this.font, label,
                rowX + 10, y + (btnH - this.font.lineHeight) / 2 + 1,
                TEXT_BRIGHT, false);
        voiceToggleX1 = rowX; voiceToggleY1 = y;
        voiceToggleX2 = rowX + rowW; voiceToggleY2 = y + btnH;
        return y + btnH;
    }

    private int drawSpeakerRow(GuiGraphics gfx, int x, int y, int w, UUID uuid, String name) {
        int rowX = x + 18;
        int faceSize = 14;
        int faceX = rowX + 2;
        int faceY = y + (CHAN_ROW_H - faceSize) / 2;
        // Green ring around the face — this row is only drawn for users
        // actively transmitting, so the ring is always lit.
        gfx.fill(faceX - 1, faceY - 1, faceX + faceSize + 1, faceY + faceSize + 1, GREEN);
        drawPlayerFace(gfx, uuid, name, faceX, faceY, faceSize);
        gfx.drawString(this.font, name,
                faceX + faceSize + 6, y + (CHAN_ROW_H - this.font.lineHeight) / 2 + 1,
                TEXT, false);
        return y + CHAN_ROW_H;
    }

    private void drawUserBar(GuiGraphics gfx, int x, int y, int w, int h) {
        gfx.fill(x, y, x + w, y + h, SERVER_RAIL_BG);
        ShadowChatClient sc = ShadowChatClient.get();
        AuthConfig auth = sc.authConfig();
        String displayName = auth.isUsable() ? auth.name() : "Not signed in";
        int avSize = 28;
        int avX = x + 8;
        int avY = y + (h - avSize) / 2;
        drawPlayerFace(gfx, parseUuid(auth.uuid()), displayName, avX, avY, avSize);
        gfx.drawString(this.font, displayName,
                avX + avSize + 8, avY + 3, TEXT_BRIGHT, false);
        String status = auth.isUsable() ? "Online" : "Sign in via launcher";
        gfx.drawString(this.font, status,
                avX + avSize + 8, avY + 3 + this.font.lineHeight + 2,
                auth.isUsable() ? GREEN : TEXT_DIM, false);

        // Right-edge buttons. Two buttons: mute + settings, stacked
        // right-to-left from the right edge with a 6 px gap. Each is
        // a 22 px square.
        int btnSize = 22;
        int rightEdge = x + w - 10;

        // Settings ⚙ — rightmost. Active state (panel open) → accent
        // fill so it's clear the user is *in* settings.
        int sBtnX2 = rightEdge;
        int sBtnX1 = sBtnX2 - btnSize;
        int sBtnY1 = y + (h - btnSize) / 2;
        int sBtnY2 = sBtnY1 + btnSize;
        int sBg = viewingSettings ? ACCENT : CHIP_HOVER;
        gfx.fill(sBtnX1, sBtnY1, sBtnX2, sBtnY2, sBg);
        String sGlyph = "*";
        int sw = this.font.width(sGlyph);
        gfx.drawString(this.font, sGlyph,
                sBtnX1 + (btnSize - sw) / 2,
                sBtnY1 + (btnSize - this.font.lineHeight) / 2 + 1,
                TEXT_BRIGHT, false);
        settingsBtnX1 = sBtnX1; settingsBtnY1 = sBtnY1;
        settingsBtnX2 = sBtnX2; settingsBtnY2 = sBtnY2;

        // Mute (headphones) — second from right. Red when muted so
        // the user notices they've silenced everyone before
        // wondering "why is voice broken". MC font doesn't have a
        // headphones glyph, so we use "H" + render a small slash
        // overlay when muted.
        boolean muted = sc.isVoiceMuted();
        int mBtnX2 = sBtnX1 - 6;
        int mBtnX1 = mBtnX2 - btnSize;
        int mBtnY1 = sBtnY1;
        int mBtnY2 = sBtnY2;
        int mBg = muted ? RED_PILL : CHIP_HOVER;
        gfx.fill(mBtnX1, mBtnY1, mBtnX2, mBtnY2, mBg);
        String mGlyph = "H";
        int mw = this.font.width(mGlyph);
        gfx.drawString(this.font, mGlyph,
                mBtnX1 + (btnSize - mw) / 2,
                mBtnY1 + (btnSize - this.font.lineHeight) / 2 + 1,
                TEXT_BRIGHT, false);
        if (muted) {
            // Diagonal slash through the H — accent-bright white so it
            // contrasts the red pill. Three pixels wide for visibility.
            for (int i = 0; i < 3; i++) {
                gfx.fill(mBtnX1 + 2 + i, mBtnY1 + btnSize - 4,
                         mBtnX1 + 3 + i, mBtnY1 + btnSize - 3, TEXT_BRIGHT);
                gfx.fill(mBtnX2 - 4 - i, mBtnY1 + 2,
                         mBtnX2 - 3 - i, mBtnY1 + 3, TEXT_BRIGHT);
            }
            // Connect the corners with a continuous line.
            for (int j = 0; j < btnSize - 6; j++) {
                gfx.fill(mBtnX1 + 3 + j, mBtnY1 + btnSize - 4 - j,
                         mBtnX1 + 4 + j, mBtnY1 + btnSize - 3 - j, TEXT_BRIGHT);
            }
        }
        muteBtnX1 = mBtnX1; muteBtnY1 = mBtnY1;
        muteBtnX2 = mBtnX2; muteBtnY2 = mBtnY2;
    }

    /**
     * Draw a player's MC head (face + hat layer) at the given pixel
     * rect. Looks up the connected server's player roster by UUID; if
     * present, uses {@link PlayerFaceRenderer} with the player's real
     * {@link PlayerSkin}. If not (sign-out state, voice peer from a
     * different MC server, etc.) falls back to a colored square with
     * the player's first-letter initial.
     */
    private void drawPlayerFace(GuiGraphics gfx, UUID uuid, String name, int x, int y, int size) {
        PlayerSkin skin = lookupSkin(uuid);
        if (skin != null) {
            PlayerFaceRenderer.draw(gfx, skin, x, y, size);
            return;
        }
        int color = NAME_COLORS[Math.floorMod(name == null ? 0 : name.hashCode(), NAME_COLORS.length)];
        gfx.fill(x, y, x + size, y + size, color);
        char initial = (name != null && !name.isEmpty())
                ? Character.toUpperCase(name.charAt(0)) : '?';
        String letter = String.valueOf(initial);
        int lw = this.font.width(letter);
        gfx.drawString(this.font, letter,
                x + (size - lw) / 2,
                y + (size - this.font.lineHeight) / 2 + 1,
                TEXT_BRIGHT, false);
    }

    /** Resolve a UUID to a PlayerSkin via the active multiplayer connection. */
    private PlayerSkin lookupSkin(UUID uuid) {
        if (uuid == null || this.minecraft == null) return null;
        // Local player short-circuit — their PlayerInfo isn't always in
        // the connection roster on world load.
        if (this.minecraft.player != null
                && uuid.equals(this.minecraft.player.getUUID())) {
            return this.minecraft.player.getSkin();
        }
        ClientPacketListener conn = this.minecraft.getConnection();
        if (conn == null) return null;
        PlayerInfo info = conn.getPlayerInfo(uuid);
        return info == null ? null : info.getSkin();
    }

    private static UUID parseUuid(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return UUID.fromString(s); } catch (Exception e) { return null; }
    }

    // ------------------------------------------------------ main area

    private void drawMain(GuiGraphics gfx, int x, int y, int w, int h, int mouseX, int mouseY) {
        gfx.fill(x, y, x + w, y + h, MAIN_BG);

        ShadowChatClient sc = ShadowChatClient.get();
        InputState st = sc.uiState();
        String activeChannel = st.activeChannel();

        // ---- header ----
        gfx.fill(x, y, x + w, y + HEADER_H, HEADER_BG);
        String headerLabel = viewingVoiceRoom
                ? "# Voice Room — " + channelDisplayName(activeChannel)
                : "# " + channelDisplayName(activeChannel);
        int labelY = y + (HEADER_H - this.font.lineHeight) / 2 + 1;
        gfx.drawString(this.font, headerLabel, x + 12, labelY, TEXT_BRIGHT, false);
        int cursor = x + 12 + this.font.width(headerLabel);
        int presence = presenceCount(st, activeChannel);
        if (presence > 0) {
            String count = presence + " online";
            cursor += 12;
            gfx.drawString(this.font, count, cursor, labelY, TEXT_DIM, false);
            cursor += this.font.width(count);
        }

        // Group ID chip + Copy button on group channels — makes invitation
        // a one-click affair instead of fishing through the chat history.
        if (activeChannel != null && activeChannel.startsWith("group:")) {
            String id = activeChannel.substring("group:".length());
            String idShort = id.length() > 8 ? id.substring(0, 8) + "…" : id;
            cursor += 16;
            gfx.drawString(this.font, "ID  " + idShort, cursor, labelY, TEXT_DIM, false);
            cursor += this.font.width("ID  " + idShort) + 8;
            // Copy button — fixed width chip.
            boolean copied = System.currentTimeMillis() < copiedFlashUntil;
            String btn = copied ? "Copied" : "Copy ID";
            int btnW = this.font.width(btn) + 10;
            int btnX1 = cursor;
            int btnY1 = y + 6;
            int btnX2 = cursor + btnW;
            int btnY2 = y + HEADER_H - 6;
            gfx.fill(btnX1, btnY1, btnX2, btnY2, copied ? GREEN : ACCENT);
            gfx.drawString(this.font, btn,
                    btnX1 + 5, btnY1 + ((btnY2 - btnY1) - this.font.lineHeight) / 2 + 1,
                    TEXT_BRIGHT, false);
            copyIdBtnX1 = btnX1; copyIdBtnY1 = btnY1;
            copyIdBtnX2 = btnX2; copyIdBtnY2 = btnY2;
        }

        // Status line on the right — truncated with ellipsis so it
        // can't overlap the channel header / group-ID chip on the
        // left. `cursor` here is the rightmost x consumed by the
        // left-side content (channel name + presence + group chips).
        // Reserve a 16 px gap between left content and the status,
        // and 12 px from the right edge.
        String status = sc.statusLine();
        if (status != null && !status.isBlank()) {
            int leftBoundary = cursor + 16;
            int rightBoundary = x + w - 12;
            int budget = Math.max(0, rightBoundary - leftBoundary);
            String shown = status;
            if (budget > 0 && this.font.width(shown) > budget) {
                while (shown.length() > 1 && this.font.width(shown + "…") > budget) {
                    shown = shown.substring(0, shown.length() - 1);
                }
                shown = shown + "…";
            }
            int statusW = this.font.width(shown);
            // Only paint if there's room — for an extremely narrow
            // header (or an extremely busy group title) we'd rather
            // hide the status than have one-character soup.
            if (budget >= this.font.width("…") + 4) {
                gfx.drawString(this.font, shown,
                        rightBoundary - statusW, labelY, TEXT_DIM, false);
            }
        }
        gfx.fill(x, y + HEADER_H - 1, x + w, y + HEADER_H, DIVIDER);

        // Empty state — replaces the input + log when the launcher hasn't
        // written usable auth yet. Most first-time users will see this.
        if (!sc.authConfig().isUsable()) {
            drawSignInCard(gfx, x, y + HEADER_H, w, h - HEADER_H);
            return;
        }

        // ---- input row (bottom) ----
        drawInput(gfx, x, y + h - INPUT_H - 8, w, INPUT_H);

        // ---- center panel: settings / voice room grid / message log ----
        int centerTop = y + HEADER_H + 4;
        int centerBottom = y + h - INPUT_H - 12;
        if (viewingSettings) {
            drawSettings(gfx, x, centerTop, w, centerBottom - centerTop, mouseX, mouseY);
        } else if (viewingVoiceRoom) {
            drawVoiceRoom(gfx, x, centerTop, w, centerBottom - centerTop, st, activeChannel);
        } else {
            drawMessages(gfx, x, centerTop, w, centerBottom - centerTop, st, activeChannel);
        }
    }

    /**
     * Render the settings panel. Each toggle row shows the friendly
     * label + a clickable on/off chip whose state is pulled live from
     * ModConfig.
     */
    private void drawSettings(GuiGraphics gfx, int x, int y, int w, int h,
                              int mouseX, int mouseY) {
        ShadowChatClient sc = ShadowChatClient.get();
        ModConfig cfg = sc.modConfig();

        // Title (fixed — only the rows below scroll)
        gfx.drawString(this.font, "Settings", x + 24, y + 16, TEXT_BRIGHT, false);
        gfx.fill(x + 24, y + 32, x + w - 24, y + 33, DIVIDER);

        // Scroll viewport: between the title divider and the bottom hint.
        // The toggle list outgrew one screen when the QoL + minigame
        // sections landed, so it scrolls; clamp against the content
        // height measured on the previous frame (self-corrects within
        // one frame after a resize).
        settingsViewTop = y + 36;
        settingsViewBottom = y + h - 30;
        int viewH = settingsViewBottom - settingsViewTop;
        int maxScroll = Math.max(0, settingsContentHeight - viewH);
        if (settingsScrollOffset > maxScroll) settingsScrollOffset = maxScroll;
        if (settingsScrollOffset < 0) settingsScrollOffset = 0;

        gfx.enableScissor(x, settingsViewTop, x + w, settingsViewBottom);
        int contentTop = settingsViewTop + 12 - settingsScrollOffset;
        int rowY = contentTop;
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Auto-open chat on world join",
                "When on, the chat screen pops open ~1 s after you join any multiplayer world.",
                "auto_open_chat", cfg.autoOpenChatOnJoin());
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Auto-rejoin voice on connect",
                "After clicking Join voice once, you stay opted in across reconnects + channel switches.",
                "auto_join_voice", cfg.autoJoinVoice());
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Mute incoming voice",
                "Silences other people's voice locally. Decoding keeps running so you can un-mute instantly.",
                "voice_muted", cfg.voiceMuted());

        // ─── Client QoL toggles ───────────────────────────────────────
        // Render a divider + sub-header so the three sections (Voice /
        // QoL / Minigame) read as visually distinct groups.
        gfx.fill(x + 24, rowY + 2, x + w - 24, rowY + 3, DIVIDER);
        rowY += 12;
        gfx.drawString(this.font, "Client QoL helpers", x + 24, rowY, TEXT_BRIGHT, false);
        rowY += this.font.lineHeight + 8;

        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Recipe preview tooltip",
                "Hover any craftable item — its ingredients + arrangement get added to the tooltip.",
                "qol_recipe", app.shadowclient.chat.qol.Qol.recipePreviewEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Coords HUD (top-right)",
                "Small XYZ + cardinal-facing overlay. Less noisy than F3 when you just want to read your position.",
                "qol_coords", app.shadowclient.chat.qol.Qol.coordsHudEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Held-item HUD",
                "Selected hotbar item floats above the bar for ~2 s when you switch slots, then fades.",
                "qol_helditem", app.shadowclient.chat.qol.Qol.heldItemHudEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Cooldown HUD (left edge)",
                "Lists your own items on cooldown (legendaries, golden heads, ability items) with time remaining. Reads only your local cooldown state; hides when nothing's cooling down.",
                "qol_cooldown", app.shadowclient.chat.qol.Qol.cooldownHudEnabled);

        // ─── Minigame helpers ─────────────────────────────────────────
        gfx.fill(x + 24, rowY + 2, x + w - 24, rowY + 3, DIVIDER);
        rowY += 12;
        gfx.drawString(this.font, "Minigame helpers", x + 24, rowY, TEXT_BRIGHT, false);
        rowY += this.font.lineHeight + 8;

        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Speed HUD",
                "Bottom-left HUD showing current speed (blocks/sec), session peak, and post-landing jump distance + height.",
                "mg_speed", app.shadowclient.chat.minigame.Minigames.speedHudEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Lap timer (ice-boat racing)",
                "Anchors a start line at the toggle position; cross it to begin lap, cross again to time it. PB tracked.",
                "mg_lap", app.shadowclient.chat.minigame.Minigames.lapTimerEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Ice block highlight",
                "Color-coded outlines on nearby ice: green=blue ice (fastest), yellow=packed, cyan=regular.",
                "mg_ice", app.shadowclient.chat.minigame.Minigames.iceHighlightEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Auto sprint",
                "Always sprint when holding W; backs off in vehicles, during sneak/item-use, or with hunger ≤ 6.",
                "mg_sprint", app.shadowclient.chat.minigame.Minigames.autoSprintEnabled);
        rowY = drawToggleRow(gfx, x + 24, rowY, w - 48, mouseX, mouseY,
                "Auto respawn",
                "Fires the respawn packet on the death screen with a 20-tick cooldown to avoid bug-loops.",
                "mg_respawn", app.shadowclient.chat.minigame.Minigames.autoRespawnEnabled);

        gfx.disableScissor();
        // Measure what we just drew so the clamp above is right next frame.
        settingsContentHeight = (rowY - contentTop) + 12;

        // Slim scrollbar on the right edge when the content overflows.
        if (maxScroll > 0) {
            int trackX = x + w - 6;
            int trackH = viewH;
            int barH = Math.max(24, (int) ((long) trackH * viewH / settingsContentHeight));
            int barY = settingsViewTop
                    + (int) ((long) (trackH - barH) * settingsScrollOffset / maxScroll);
            gfx.fill(trackX, settingsViewTop, trackX + 3, settingsViewBottom, 0x30FFFFFF);
            gfx.fill(trackX, barY, trackX + 3, barY + barH, 0x90FFFFFF);
        }

        // Hint at the bottom — keyboard shortcuts users might miss.
        int hintY = y + h - 22;
        gfx.drawString(this.font,
                "Scroll for more settings. Click the gear again to close; ; reopens chat.",
                x + 24, hintY, TEXT_DIM, false);
    }

    /**
     * One label + clickable on/off chip. Returns the y after the row
     * so callers can stack them. Adds an entry to
     * {@link #settingsToggleHits} keyed by the toggle's name; the
     * click handler maps that key back to the right ModConfig setter.
     */
    private int drawToggleRow(GuiGraphics gfx, int x, int y, int w,
                              int mouseX, int mouseY,
                              String label, String subLabel, String key, boolean on) {
        int rowH = 38;
        // Toggle chip on the right.
        int chipW = 56;
        int chipH = 22;
        int chipX2 = x + w - 4;
        int chipX1 = chipX2 - chipW;
        int chipY1 = y + (rowH - chipH) / 2;
        int chipY2 = chipY1 + chipH;
        boolean hover = mouseX >= chipX1 && mouseX <= chipX2
                && mouseY >= chipY1 && mouseY <= chipY2;
        int bg = on ? (hover ? 0xFF3C8C46 : 0xFF2A6638)
                    : (hover ? CHIP_HOVER : CHIP_ACTIVE);
        gfx.fill(chipX1, chipY1, chipX2, chipY2, bg);
        String chipLabel = on ? "ON" : "OFF";
        int tw = this.font.width(chipLabel);
        gfx.drawString(this.font, chipLabel,
                chipX1 + (chipW - tw) / 2,
                chipY1 + (chipH - this.font.lineHeight) / 2 + 1,
                on ? TEXT_BRIGHT : TEXT_DIM, false);

        // Label + sub-label on the left.
        gfx.drawString(this.font, label, x, y + 6, TEXT_BRIGHT, false);
        gfx.drawString(this.font, subLabel, x, y + 6 + this.font.lineHeight + 4,
                TEXT_DIM, false);

        // Only chips actually inside the scroll viewport are clickable —
        // rows scissored away must not be invisibly hit-testable.
        if (chipY2 >= settingsViewTop && chipY1 <= settingsViewBottom) {
            settingsToggleHits.add(new ToggleHit(chipX1, chipY1, chipX2, chipY2, key));
        }
        return y + rowH + 8;
    }

    /**
     * Render a Voice Room grid of avatar tiles. Each tile shows the
     * participant's MC head (via PlayerFaceRenderer when we have a
     * PlayerInfo for them on the current server, fallback to a
     * colored-letter square otherwise), their name, and a green
     * speaking ring when they're currently transmitting.
     *
     * Roster comes from {@link InputState#voiceRosterFor} which is
     * populated by the relay's voice:roster broadcast. Empty roster
     * shows an empty-state hint instead of a blank grid.
     */
    private void drawVoiceRoom(GuiGraphics gfx, int x, int y, int w, int h,
                               InputState st, String activeChannel) {
        ShadowChatClient sc = ShadowChatClient.get();
        List<ServerEvent.User> roster = st.voiceRosterFor(activeChannel);
        VoiceController vc = sc.voice();
        java.util.Set<UUID> currentSpeakers = new java.util.HashSet<>(
                vc != null ? vc.playback().currentSpeakers() : List.of());

        if (roster.isEmpty()) {
            // Empty-state card — push the user toward Join Voice with
            // an inline button so they don't have to find the sidebar
            // one separately.
            int cardW = Math.min(440, w - 80);
            int cardH = 138;
            int cardX = x + (w - cardW) / 2;
            int cardY = y + (h - cardH) / 2;
            gfx.fill(cardX, cardY, cardX + cardW, cardY + cardH, SIDEBAR_BG);
            gfx.fill(cardX, cardY, cardX + 4, cardY + cardH, ACCENT);
            gfx.drawString(this.font, "No one's in voice on this channel yet.",
                    cardX + 18, cardY + 18, TEXT_BRIGHT, false);
            gfx.drawString(this.font, "Be the first to join — others' avatars will appear here as",
                    cardX + 18, cardY + 18 + this.font.lineHeight + 6, TEXT_DIM, false);
            gfx.drawString(this.font, "they opt in. Then click Mic in the input row to talk.",
                    cardX + 18, cardY + 18 + (this.font.lineHeight + 6) * 2, TEXT_DIM, false);

            // Inline action button — disabled if we aren't connected
            // because toggleVoiceOptIn would just print a "Not
            // connected" error.
            boolean alreadyIn = sc.isInVoice();
            String btnLabel = alreadyIn ? "Leave voice" : "Join voice";
            int btnW = Math.max(120, this.font.width(btnLabel) + 28);
            int btnH = 26;
            int btnX = cardX + 18;
            int btnY = cardY + cardH - btnH - 14;
            int bg = alreadyIn ? RED_PILL : 0xFF2A6638;
            gfx.fill(btnX, btnY, btnX + btnW, btnY + btnH, bg);
            int lw = this.font.width(btnLabel);
            gfx.drawString(this.font, btnLabel,
                    btnX + (btnW - lw) / 2,
                    btnY + (btnH - this.font.lineHeight) / 2 + 1,
                    TEXT_BRIGHT, false);
            emptyJoinBtnX1 = btnX; emptyJoinBtnY1 = btnY;
            emptyJoinBtnX2 = btnX + btnW; emptyJoinBtnY2 = btnY + btnH;
            return;
        }

        // Grid layout — square tiles ~96 px on a side, fit-to-width.
        final int TILE_W = 96;
        final int TILE_H = 116;
        final int GAP = 12;
        int innerW = w - 24;
        int cols = Math.max(1, (innerW + GAP) / (TILE_W + GAP));
        int gridLeft = x + 12 + Math.max(0, (innerW - (cols * TILE_W + (cols - 1) * GAP)) / 2);
        int drawY = y + 4;
        int drawX = gridLeft;
        int colIdx = 0;
        for (ServerEvent.User member : roster) {
            UUID uuid = parseUuid(member.uuid());
            // Prefer the display name the relay sent with the roster; fall
            // back to the presence-derived name only when the roster entry
            // carried none (bare-uuid or back-compat wire shapes).
            String name = member.name() != null && !member.name().isBlank()
                    ? member.name()
                    : sc.displayNameForUuid(uuid);
            boolean speaking = uuid != null && currentSpeakers.contains(uuid);
            drawVoiceTile(gfx, drawX, drawY, TILE_W, TILE_H, uuid, name, speaking);
            colIdx++;
            if (colIdx >= cols) {
                colIdx = 0;
                drawX = gridLeft;
                drawY += TILE_H + GAP;
                if (drawY + TILE_H > y + h) break; // ran out of room
            } else {
                drawX += TILE_W + GAP;
            }
        }
    }

    private void drawVoiceTile(GuiGraphics gfx, int x, int y, int w, int h,
                               UUID uuid, String name, boolean speaking) {
        // Tile background — slightly elevated.
        gfx.fill(x, y, x + w, y + h, SIDEBAR_BG);
        if (speaking) {
            // Outer green frame when currently transmitting.
            gfx.fill(x, y, x + w, y + 2, GREEN);
            gfx.fill(x, y + h - 2, x + w, y + h, GREEN);
            gfx.fill(x, y, x + 2, y + h, GREEN);
            gfx.fill(x + w - 2, y, x + w, y + h, GREEN);
        }
        // Face centered horizontally in the tile.
        int faceSize = 48;
        int faceX = x + (w - faceSize) / 2;
        int faceY = y + 16;
        if (speaking) {
            // Inner glow under the face — slightly green tint.
            gfx.fill(faceX - 3, faceY - 3, faceX + faceSize + 3, faceY + faceSize + 3, 0x804ADE80);
        }
        drawPlayerFace(gfx, uuid, name, faceX, faceY, faceSize);
        // Name underneath, truncated to tile width.
        String shown = name;
        if (this.font.width(shown) > w - 8) {
            while (shown.length() > 1 && this.font.width(shown + "…") > w - 8) {
                shown = shown.substring(0, shown.length() - 1);
            }
            shown = shown + "…";
        }
        int nameX = x + (w - this.font.width(shown)) / 2;
        gfx.drawString(this.font, shown,
                nameX, faceY + faceSize + 8,
                speaking ? GREEN : TEXT_BRIGHT, false);
    }

    /** Centered empty-state card: "Sign in via the launcher to chat". */
    private void drawSignInCard(GuiGraphics gfx, int x, int y, int w, int h) {
        int cardW = Math.min(420, w - 80);
        int cardH = 150;
        int cardX = x + (w - cardW) / 2;
        int cardY = y + (h - cardH) / 2;
        gfx.fill(cardX, cardY, cardX + cardW, cardY + cardH, SIDEBAR_BG);
        // Brand-blue accent strip on the left edge.
        gfx.fill(cardX, cardY, cardX + 4, cardY + cardH, ACCENT);

        int textX = cardX + 24;
        int lineY = cardY + 22;
        gfx.drawString(this.font, "Sign in to chat", textX, lineY, TEXT_BRIGHT, false);
        lineY += this.font.lineHeight + 10;
        gfx.drawString(this.font, "Shadow Chat needs your Microsoft account",
                textX, lineY, TEXT, false);
        lineY += this.font.lineHeight + 4;
        gfx.drawString(this.font, "to verify who you are when sending messages.",
                textX, lineY, TEXT, false);
        lineY += this.font.lineHeight + 12;
        gfx.drawString(this.font, "1. Open the Shadow Client launcher",
                textX, lineY, TEXT_DIM, false);
        lineY += this.font.lineHeight + 2;
        gfx.drawString(this.font, "2. Click Sign in with Microsoft",
                textX, lineY, TEXT_DIM, false);
        lineY += this.font.lineHeight + 2;
        gfx.drawString(this.font, "3. Launch this profile again",
                textX, lineY, TEXT_DIM, false);
    }

    /**
     * One renderable row of the message log. Exactly one variant is set:
     * a real message line, a centered day-separator label, or the
     * NEW-messages divider. Synthetic rows consume one line-height just
     * like messages, so the scroll/window math stays purely row-based
     * and nothing can overlap or double-draw.
     */
    private record LogRow(InputState.DisplayLine line, String dayLabel, boolean newMarker) {}

    /**
     * Interleave the channel's messages with synthetic rows: a day
     * separator between consecutive messages whose timestamps fall on
     * different LOCAL calendar days, and the NEW divider immediately
     * above the first-unread line captured at screen-open. Identity
     * match ({@code ==}) is deliberate — {@link InputState#linesFor}
     * snapshots hand back the same DisplayLine instances, so the
     * divider stays pinned as newer lines append and silently vanishes
     * if the anchor line is evicted from the ring buffer.
     */
    private List<LogRow> buildLogRows(List<InputState.DisplayLine> lines) {
        List<LogRow> rows = new ArrayList<>(lines.size() + 8);
        ZoneId zone = ZoneId.systemDefault();
        LocalDate today = LocalDate.now(zone);
        LocalDate prevDay = null;
        for (InputState.DisplayLine line : lines) {
            LocalDate day = Instant.ofEpochMilli(line.ts()).atZone(zone).toLocalDate();
            if (prevDay != null && !day.equals(prevDay)) {
                rows.add(new LogRow(null, dayLabel(day, today), false));
            }
            prevDay = day;
            if (line == firstUnreadAtOpen) {
                rows.add(new LogRow(null, null, true));
            }
            rows.add(new LogRow(line, null, false));
        }
        return rows;
    }

    /** "— Today —" / "— Yesterday —" / "— 2026-06-09 —" for older days. */
    private static String dayLabel(LocalDate day, LocalDate today) {
        if (day.equals(today)) return "— Today —";
        if (day.equals(today.minusDays(1))) return "— Yesterday —";
        return "— " + day + " —";
    }

    /**
     * The NEW-messages divider: a thin accent line across the row with a
     * small right-aligned "NEW" tag, drawn immediately above the first
     * message that arrived while the screen was closed.
     */
    private void drawNewMarker(GuiGraphics gfx, int x, int drawY, int w) {
        String tag = "NEW";
        int tagW = this.font.width(tag);
        int tagX = x + w - 16 - tagW;
        int lineY = drawY + this.font.lineHeight / 2;
        gfx.fill(x + 12, lineY, tagX - 6, lineY + 1, ACCENT);
        gfx.drawString(this.font, tag, tagX, drawY, ACCENT, false);
    }

    /** Centered dim day-separator row ("— Today —" etc.). */
    private void drawDaySeparator(GuiGraphics gfx, int x, int drawY, int w, String label) {
        int lw = this.font.width(label);
        gfx.drawString(this.font, label, x + Math.max(12, (w - lw) / 2), drawY, TEXT_DIM, false);
    }

    private void drawMessages(GuiGraphics gfx, int x, int y, int w, int h,
                              InputState st, String activeChannel) {
        int lineH = this.font.lineHeight + 4;
        int maxLines = Math.max(0, h / lineH);
        if (maxLines == 0) return;
        // Reset scroll if user switched channels — different log, different
        // bottom. Sticking to the previous offset would land us mid-log.
        if (!activeChannel.equals(scrollAnchorChannel)) {
            scrollOffset = 0;
            scrollAnchorChannel = activeChannel;
        }
        List<InputState.DisplayLine> lines = st.linesFor(activeChannel);
        List<LogRow> rows = buildLogRows(lines);
        // Clamp scrollOffset against the current row count so it can't sit
        // past the oldest row after eviction.
        int maxScroll = Math.max(0, rows.size() - maxLines);
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        if (scrollOffset < 0) scrollOffset = 0;
        int endExclusive = rows.size() - scrollOffset;
        int start = Math.max(0, endExclusive - maxLines);
        int visible = endExclusive - start;
        int drawY = y + Math.max(0, h - visible * lineH);
        int textMaxRight = x + w - 16;
        for (int i = start; i < endExclusive; i++) {
            LogRow row = rows.get(i);
            if (row.newMarker()) {
                drawNewMarker(gfx, x, drawY, w);
            } else if (row.dayLabel() != null) {
                drawDaySeparator(gfx, x, drawY, w, row.dayLabel());
            } else {
                drawMessageLine(gfx, x + 12, drawY, textMaxRight, row.line());
            }
            drawY += lineH;
        }
        // "Scrolled up — jump to latest" hint when we're not anchored to bottom.
        if (scrollOffset > 0) {
            String hint = "↑ Scrolled up " + scrollOffset + " line"
                    + (scrollOffset == 1 ? "" : "s")
                    + " — scroll down to follow";
            int hw = this.font.width(hint);
            gfx.fill(x + w - hw - 24, y + h - this.font.lineHeight - 10,
                     x + w - 8, y + h - 4, 0xC0202329);
            gfx.drawString(this.font, hint,
                    x + w - hw - 16, y + h - this.font.lineHeight - 6,
                    ACCENT, false);
        }
    }

    /** Render one message line: timestamp + colored name + » + text (or system/error variant). */
    private void drawMessageLine(GuiGraphics gfx, int x, int y, int xRight,
                                 InputState.DisplayLine line) {
        String ts = HHMMSS.format(Instant.ofEpochMilli(line.ts()));
        int cursor = x;
        gfx.drawString(this.font, ts, cursor, y, TEXT_DIM, false);
        cursor += this.font.width(ts) + 6;
        if (line.error()) {
            gfx.drawString(this.font, line.text(), cursor, y, RED_PILL, false);
            return;
        }
        if (line.system()) {
            gfx.drawString(this.font, line.text(), cursor, y, TEXT_DIM, false);
            return;
        }
        String name = line.name() == null ? "?" : line.name();
        String sep = " » ";
        boolean isCoords = looksLikeCoords(line.text());
        if (isCoords) {
            int rightEdge = Math.min(xRight,
                    cursor + this.font.width(name) + this.font.width(sep) + this.font.width(line.text()) + 6);
            int hitX1 = cursor - 2;
            int hitY1 = y - 1;
            int hitX2 = rightEdge + 2;
            int hitY2 = y + this.font.lineHeight + 1;
            gfx.fill(hitX1, hitY1, hitX2, hitY2, COORDS_HIGHLIGHT);
            // Register the line for click-to-copy. The text we copy
            // is the coords body only (no name / timestamp) so it
            // pastes cleanly into in-game chat.
            coordsHits.add(new CoordsHit(hitX1, hitY1, hitX2, hitY2, line.text()));
            // "Copied" overlay when this line was just clicked.
            if (System.currentTimeMillis() < coordsCopiedUntil
                    && copiedLineX1 == hitX1 && copiedLineY1 == hitY1) {
                String badge = "Copied";
                int bw = this.font.width(badge) + 10;
                int bx2 = hitX2 - 2;
                int bx1 = bx2 - bw;
                gfx.fill(bx1, hitY1, bx2, hitY2, GREEN);
                gfx.drawString(this.font, badge,
                        bx1 + 5, y, TEXT_BRIGHT, false);
            }
        }
        gfx.drawString(this.font, name, cursor, y, nameColor(name), false);
        cursor += this.font.width(name);
        gfx.drawString(this.font, sep, cursor, y, TEXT_DIM, false);
        cursor += this.font.width(sep);
        // Truncate body so we don't paint past xRight.
        String text = line.text();
        if (cursor + this.font.width(text) > xRight) {
            while (text.length() > 1 && cursor + this.font.width(text + "...") > xRight) {
                text = text.substring(0, text.length() - 1);
            }
            text = text + "...";
        }
        gfx.drawString(this.font, text, cursor, y, isCoords ? ACCENT : TEXT_BRIGHT, false);
    }

    private void drawInput(GuiGraphics gfx, int x, int y, int w, int h) {
        int padX = 12;
        int boxX1 = x + padX;
        int boxX2 = x + w - padX;
        gfx.fill(boxX1, y, boxX2, y + h, INPUT_BG);

        // "+" pill on far left of input
        int plusW = 24;
        int plusX1 = boxX1 + 4;
        int plusX2 = plusX1 + plusW;
        int plusY1 = y + 6;
        int plusY2 = y + h - 6;
        gfx.fill(plusX1, plusY1, plusX2, plusY2, CHIP_HOVER);
        int plusTextW = this.font.width("+");
        gfx.drawString(this.font, "+",
                plusX1 + (plusW - plusTextW) / 2,
                plusY1 + ((plusY2 - plusY1) - this.font.lineHeight) / 2 + 1,
                TEXT, false);

        // Mic toggle button — rightmost. Four states:
        //   - No mic         (capture device unavailable; click is a no-op)
        //   - Mic            (off; click arms hot-mic)
        //   - Mic ●          (hot-mic armed but currently silent; click disarms)
        //   - ● Talking      (actively transmitting — PTT held or hot-mic on +
        //                     real audio leaving the box; click disarms hot-mic)
        ShadowChatClient scForMic = ShadowChatClient.get();
        VoiceController vcForMic = scForMic.voice();
        boolean micAvailable = vcForMic != null && vcForMic.capture().isAvailable();
        boolean transmitting = vcForMic != null && vcForMic.isTransmitting();
        boolean micArmed = scForMic.isHotMicOn();
        String micLabel;
        int micBg, micFg;
        if (!micAvailable) {
            micLabel = "No mic";
            micBg = 0xFF2A2A2A;
            micFg = TEXT_DIM;
        } else if (transmitting) {
            // Subtle pulse so the user notices they're hot.
            boolean blink = System.currentTimeMillis() % 800 < 400;
            micLabel = "● Talking";
            micBg = blink ? RED_PILL : 0xFFC23A3A;
            micFg = TEXT_BRIGHT;
        } else if (micArmed) {
            micLabel = "Mic ●";
            micBg = 0xFFD89B2A;       // amber — armed but silent
            micFg = TEXT_BRIGHT;
        } else {
            micLabel = "Mic";
            micBg = CHIP_HOVER;
            micFg = TEXT;
        }
        int micW = this.font.width(micLabel) + 14;
        int micBX2 = boxX2 - 6;
        int micBX1 = micBX2 - micW;
        int micBY1 = y + 6;
        int micBY2 = y + h - 6;
        gfx.fill(micBX1, micBY1, micBX2, micBY2, micBg);
        gfx.drawString(this.font, micLabel,
                micBX1 + 7,
                micBY1 + ((micBY2 - micBY1) - this.font.lineHeight) / 2 + 1,
                micFg, false);
        // Only register the hit-rect when the mic is usable — clicking a
        // greyed-out "No mic" button shouldn't do anything.
        if (micAvailable) {
            micBtnX1 = micBX1; micBtnY1 = micBY1;
            micBtnX2 = micBX2; micBtnY2 = micBY2;
        }

        // Coords button — just left of the Mic button.
        String btnLabel = "Coords";
        int btnW = this.font.width(btnLabel) + 14;
        int btnX2 = micBX1 - 6;
        int btnX1 = btnX2 - btnW;
        int btnY1 = y + 6;
        int btnY2 = y + h - 6;
        boolean coordsEnabled = CoordsHelper.hasPlayer();
        int btnBg = coordsEnabled ? ACCENT : 0xFF2A2A2A;
        int btnFg = coordsEnabled ? TEXT_BRIGHT : TEXT_DIM;
        gfx.fill(btnX1, btnY1, btnX2, btnY2, btnBg);
        gfx.drawString(this.font, btnLabel,
                btnX1 + 7,
                btnY1 + ((btnY2 - btnY1) - this.font.lineHeight) / 2 + 1,
                btnFg, false);
        if (coordsEnabled) {
            coordsBtnX1 = btnX1; coordsBtnY1 = btnY1;
            coordsBtnX2 = btnX2; coordsBtnY2 = btnY2;
        }

        // Text caret area between plus and coords.
        int textX1 = plusX2 + 8;
        int textX2 = btnX1 - 8;
        int avail = Math.max(0, textX2 - textX1);
        int textY = y + (h - this.font.lineHeight) / 2 + 1;
        clampCaret();
        if (buffer.length() == 0) {
            // Placeholder + a dim caret at the start.
            String placeholder = "Message #"
                    + channelDisplayName(ShadowChatClient.get().uiState().activeChannel()) + "...";
            String shown = placeholder;
            if (this.font.width(shown) > avail) {
                while (shown.length() > 1 && this.font.width(shown + "...") > avail) {
                    shown = shown.substring(0, shown.length() - 1);
                }
                shown = shown + "...";
            }
            gfx.drawString(this.font, shown, textX1, textY, TEXT_DIM, false);
            if (System.currentTimeMillis() % 1000 < 500) {
                gfx.fill(textX1, y + 8, textX1 + 1, y + h - 8, TEXT_DIM);
            }
        } else {
            // Single-line field with a horizontal scroll that keeps the
            // caret in view: left-anchored until the caret runs past the
            // right edge, then it tracks the caret. Computed fresh each
            // frame (stateless) from the caret's pixel offset.
            String text = buffer.toString();
            int caretOffset = this.font.width(text.substring(0, caret));
            int scrollPx = 0;
            if (caretOffset - scrollPx > avail - 2) scrollPx = caretOffset - (avail - 2);
            if (caretOffset - scrollPx < 0) scrollPx = caretOffset;
            if (scrollPx < 0) scrollPx = 0;
            // Clip text + caret to the field so a long line can't paint
            // over the Coords / Mic buttons.
            gfx.enableScissor(textX1, y, textX2, y + h);
            gfx.drawString(this.font, text, textX1 - scrollPx, textY, TEXT_BRIGHT, false);
            if (System.currentTimeMillis() % 1000 < 500) {
                int caretX = textX1 - scrollPx + caretOffset;
                gfx.fill(caretX, y + 8, caretX + 1, y + h - 8, TEXT_BRIGHT);
            }
            gfx.disableScissor();
        }

        // Character counter when approaching the 512-char cap. Hidden
        // when the buffer is short (~ < 80%) to keep the input row
        // uncluttered for the common case. Amber as we approach the
        // limit, red when at it — and at the cap the user is silently
        // dropping further keystrokes via insertAtCaret, which is
        // confusing without this indicator.
        int len = buffer.length();
        int threshold = MAX_INPUT * 4 / 5;       // 80 %
        if (len >= threshold) {
            String counter = len + " / " + MAX_INPUT;
            int color2 = (len >= MAX_INPUT) ? RED_PILL
                                            : 0xFFD89B2A;   // amber
            int cw = this.font.width(counter);
            // Float the counter just above the input pill, right-aligned.
            int cx = boxX2 - cw - 8;
            int cy = y - this.font.lineHeight - 2;
            gfx.drawString(this.font, counter, cx, cy, color2, false);
        }
    }

    // ============================================================ input

    @Override
    public boolean keyPressed(KeyEvent event) {
        int keyCode = event.key();
        int modifiers = event.modifiers();
        boolean ctrl = (modifiers & GLFW.GLFW_MOD_CONTROL) != 0;
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            String text = buffer.toString().trim();
            buffer.setLength(0);
            caret = 0;
            historyIndex = -1;
            if (!text.isEmpty()) {
                // Record before dispatch so even slash-commands are recallable.
                pushHistory(text);
                ShadowChatClient.get().submitInput(text);
            }
            this.onClose();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (ctrl) deletePrevWord();
            else deleteBeforeCaret();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DELETE) {
            deleteAtCaret();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            clampCaret();
            caret = ctrl ? prevWordBoundary(caret) : Math.max(0, caret - 1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            clampCaret();
            caret = ctrl ? nextWordBoundary(caret) : Math.min(buffer.length(), caret + 1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_HOME) {
            caret = 0;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_END) {
            caret = buffer.length();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            recallHistory(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            recallHistory(+1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            buffer.setLength(0);
            caret = 0;
            this.onClose();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_V && ctrl) {
            if (this.minecraft != null) {
                String clip = this.minecraft.keyboardHandler.getClipboard();
                if (clip != null) insertAtCaret(clip.replace('\n', ' ').replace('\r', ' '));
            }
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        // Settings panel open → the wheel scrolls the toggle list, not
        // the chat history behind it. 24 px per notch ≈ half a row.
        if (viewingSettings) {
            settingsScrollOffset -= (int) (Math.signum(scrollY) * 24);
            // Upper clamp happens in drawSettings against the measured
            // content height; just floor here.
            if (settingsScrollOffset < 0) settingsScrollOffset = 0;
            return true;
        }
        // Three lines per notch — feels about right vs Discord's smoother
        // pixel scrolling.
        int delta = (int) Math.signum(scrollY) * 3;
        // scrollY positive = wheel up = look further back in history.
        scrollOffset += delta;
        if (scrollOffset < 0) scrollOffset = 0;
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if (cp >= 32 && cp != 127) {
            insertAtCaret(new String(Character.toChars(cp)));
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();

        // Coords paste button.
        if (coordsBtnX2 > 0
                && mx >= coordsBtnX1 && mx <= coordsBtnX2
                && my >= coordsBtnY1 && my <= coordsBtnY2) {
            CoordsHelper.currentCoords().ifPresent(coords -> {
                // Insert at the caret; add a leading space only when the
                // char immediately before the caret is a non-space.
                if (caret > 0 && caret <= buffer.length()
                        && buffer.charAt(caret - 1) != ' ') insertAtCaret(" ");
                insertAtCaret(coords);
            });
            return true;
        }

        // Mic toggle — flips hot-mic transmission. ShadowChatClient
        // takes care of opting in to voice if we hadn't already.
        if (micBtnX2 > 0
                && mx >= micBtnX1 && mx <= micBtnX2
                && my >= micBtnY1 && my <= micBtnY2) {
            ShadowChatClient.get().toggleHotMic();
            return true;
        }

        // "+ Create group" — pops a default-named group and switches to it.
        if (createGroupX2 > 0
                && mx >= createGroupX1 && mx <= createGroupX2
                && my >= createGroupY1 && my <= createGroupY2) {
            ShadowChatClient.get().createGroupFromUi();
            return true;
        }

        // Voice toggle button.
        if (voiceToggleX2 > 0
                && mx >= voiceToggleX1 && mx <= voiceToggleX2
                && my >= voiceToggleY1 && my <= voiceToggleY2) {
            ShadowChatClient.get().toggleVoiceOptIn();
            return true;
        }

        // Inline "Join voice" / "Leave voice" on the voice-room
        // empty-state card.
        if (emptyJoinBtnX2 > 0
                && mx >= emptyJoinBtnX1 && mx <= emptyJoinBtnX2
                && my >= emptyJoinBtnY1 && my <= emptyJoinBtnY2) {
            ShadowChatClient.get().toggleVoiceOptIn();
            return true;
        }

        // Voice-room view toggle — flip the main area.
        if (voiceRoomBtnX2 > 0
                && mx >= voiceRoomBtnX1 && mx <= voiceRoomBtnX2
                && my >= voiceRoomBtnY1 && my <= voiceRoomBtnY2) {
            viewingVoiceRoom = !viewingVoiceRoom;
            viewingSettings = false;
            return true;
        }

        // Settings ⚙ button in the user bar — flip into / out of
        // settings view; close the voice-room view if it was open.
        if (settingsBtnX2 > 0
                && mx >= settingsBtnX1 && mx <= settingsBtnX2
                && my >= settingsBtnY1 && my <= settingsBtnY2) {
            viewingSettings = !viewingSettings;
            if (viewingSettings) viewingVoiceRoom = false;
            settingsScrollOffset = 0; // always reopen at the top
            return true;
        }

        // Mute (headphones) button in the user bar — quick-access
        // alias for the settings panel's "Mute incoming voice" row.
        if (muteBtnX2 > 0
                && mx >= muteBtnX1 && mx <= muteBtnX2
                && my >= muteBtnY1 && my <= muteBtnY2) {
            ShadowChatClient.get().toggleVoiceMuted();
            return true;
        }

        // Coords share lines — click anywhere on the highlighted
        // line to copy the coords body to the system clipboard.
        for (CoordsHit hit : coordsHits) {
            if (mx >= hit.x1 && mx <= hit.x2 && my >= hit.y1 && my <= hit.y2) {
                if (this.minecraft != null) {
                    this.minecraft.keyboardHandler.setClipboard(hit.text);
                }
                coordsCopiedUntil = System.currentTimeMillis() + 1200;
                copiedLineX1 = hit.x1; copiedLineY1 = hit.y1;
                copiedLineX2 = hit.x2; copiedLineY2 = hit.y2;
                return true;
            }
        }

        // Settings toggle chips — map the chip key to the right
        // ModConfig setter. Adding a toggle? Add a branch here.
        for (ToggleHit hit : settingsToggleHits) {
            if (mx >= hit.x1 && mx <= hit.x2 && my >= hit.y1 && my <= hit.y2) {
                ShadowChatClient sc = ShadowChatClient.get();
                ModConfig cfg = sc.modConfig();
                switch (hit.key) {
                    case "auto_open_chat" -> cfg.setAutoOpenChatOnJoin(!cfg.autoOpenChatOnJoin());
                    case "auto_join_voice" -> cfg.setAutoJoinVoice(!cfg.autoJoinVoice());
                    // Route mute through ShadowChatClient so VoicePlayback
                    // picks the change up live instead of waiting for the
                    // next restart.
                    case "voice_muted" -> sc.toggleVoiceMuted();
                    // QoL toggles — flip the static booleans owned by the
                    // qol / minigame packages, mirroring each flip into the
                    // persisted config so it survives restarts (lap timer
                    // excepted — its start line is per-track).
                    case "qol_recipe"   -> {
                        boolean v = !app.shadowclient.chat.qol.Qol.recipePreviewEnabled;
                        app.shadowclient.chat.qol.Qol.recipePreviewEnabled = v;
                        cfg.setHelperToggle("recipe_preview", v);
                    }
                    case "qol_coords"   -> {
                        boolean v = !app.shadowclient.chat.qol.Qol.coordsHudEnabled;
                        app.shadowclient.chat.qol.Qol.coordsHudEnabled = v;
                        cfg.setHelperToggle("coords_hud", v);
                    }
                    case "qol_helditem" -> {
                        boolean v = !app.shadowclient.chat.qol.Qol.heldItemHudEnabled;
                        app.shadowclient.chat.qol.Qol.heldItemHudEnabled = v;
                        cfg.setHelperToggle("held_item_hud", v);
                    }
                    case "qol_cooldown" -> {
                        boolean v = !app.shadowclient.chat.qol.Qol.cooldownHudEnabled;
                        app.shadowclient.chat.qol.Qol.cooldownHudEnabled = v;
                        cfg.setHelperToggle("cooldown_hud", v);
                    }
                    case "mg_speed"     -> {
                        boolean v = !app.shadowclient.chat.minigame.Minigames.speedHudEnabled;
                        app.shadowclient.chat.minigame.Minigames.speedHudEnabled = v;
                        cfg.setHelperToggle("speed_hud", v);
                    }
                    case "mg_lap"       -> {
                        boolean now = !app.shadowclient.chat.minigame.Minigames.lapTimerEnabled;
                        app.shadowclient.chat.minigame.Minigames.lapTimerEnabled = now;
                        // Mirror the slash-command behavior: anchor on
                        // enable, clear everything on disable.
                        if (now) app.shadowclient.chat.minigame.LapTimer.anchorStartLineHere();
                        else     app.shadowclient.chat.minigame.LapTimer.clearAll();
                    }
                    case "mg_ice"       -> {
                        boolean v = !app.shadowclient.chat.minigame.Minigames.iceHighlightEnabled;
                        app.shadowclient.chat.minigame.Minigames.iceHighlightEnabled = v;
                        cfg.setHelperToggle("ice_highlight", v);
                    }
                    case "mg_sprint"    -> {
                        boolean v = !app.shadowclient.chat.minigame.Minigames.autoSprintEnabled;
                        app.shadowclient.chat.minigame.Minigames.autoSprintEnabled = v;
                        cfg.setHelperToggle("auto_sprint", v);
                    }
                    case "mg_respawn"   -> {
                        boolean v = !app.shadowclient.chat.minigame.Minigames.autoRespawnEnabled;
                        app.shadowclient.chat.minigame.Minigames.autoRespawnEnabled = v;
                        cfg.setHelperToggle("auto_respawn", v);
                    }
                    default -> {}
                }
                return true;
            }
        }

        // Copy group ID button — pulls the active channel's group UUID
        // onto the system clipboard and flashes "Copied" for ~1.2s.
        if (copyIdBtnX2 > 0
                && mx >= copyIdBtnX1 && mx <= copyIdBtnX2
                && my >= copyIdBtnY1 && my <= copyIdBtnY2) {
            String ch = ShadowChatClient.get().uiState().activeChannel();
            if (ch != null && ch.startsWith("group:") && this.minecraft != null) {
                this.minecraft.keyboardHandler.setClipboard(ch.substring("group:".length()));
                copiedFlashUntil = System.currentTimeMillis() + 1200;
            }
            return true;
        }

        // Channel rows.
        for (ChannelHit hit : channelHits) {
            if (mx >= hit.x1 && mx <= hit.x2 && my >= hit.y1 && my <= hit.y2) {
                ShadowChatClient.get().switchChannel(hit.channelKey);
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    // ============================================================ helpers

    /**
     * Insert {@code s} at the caret, honoring the {@link #MAX_INPUT} cap
     * (truncating the inserted text to whatever room is left), and move
     * the caret to the end of what was inserted. Replaces the old
     * append-only {@code appendSafe}; every typing / paste path routes
     * through here so the caret stays correct.
     */
    private void insertAtCaret(String s) {
        if (s == null || s.isEmpty()) return;
        clampCaret();
        int room = MAX_INPUT - buffer.length();
        if (room <= 0) return;
        if (s.length() > room) s = s.substring(0, room);
        buffer.insert(caret, s);
        caret += s.length();
        clampCaret();
    }

    /** Clamp {@link #caret} into [0, buffer.length()]. */
    private void clampCaret() {
        if (caret < 0) caret = 0;
        if (caret > buffer.length()) caret = buffer.length();
    }

    /** Backspace at the caret: delete the char immediately before it. */
    private void deleteBeforeCaret() {
        clampCaret();
        if (caret > 0) {
            buffer.deleteCharAt(caret - 1);
            caret--;
        }
    }

    /** DELETE at the caret: delete the char immediately after it. */
    private void deleteAtCaret() {
        clampCaret();
        if (caret < buffer.length()) {
            buffer.deleteCharAt(caret);
        }
    }

    /** Ctrl+Backspace: delete from the previous word boundary to the caret. */
    private void deletePrevWord() {
        clampCaret();
        int target = prevWordBoundary(caret);
        if (target < caret) {
            buffer.delete(target, caret);
            caret = target;
        }
    }

    /**
     * Index of the start of the word before {@code from}: skip any
     * spaces immediately left of the caret, then skip the run of
     * non-space chars. Mirrors a terminal's Ctrl+Left / Ctrl+Backspace.
     */
    private int prevWordBoundary(int from) {
        int i = Math.min(from, buffer.length());
        while (i > 0 && buffer.charAt(i - 1) == ' ') i--;
        while (i > 0 && buffer.charAt(i - 1) != ' ') i--;
        return i;
    }

    /**
     * Index of the start of the next word after {@code from}: skip the
     * current run of non-space chars, then skip the following spaces, so
     * the caret lands on the first char of the next word.
     */
    private int nextWordBoundary(int from) {
        int len = buffer.length();
        int i = Math.max(0, from);
        while (i < len && buffer.charAt(i) != ' ') i++;
        while (i < len && buffer.charAt(i) == ' ') i++;
        return i;
    }

    /**
     * Replace the whole buffer with {@code s} and drop the caret at the
     * end — used by history recall (UP / DOWN).
     */
    private void setBuffer(String s) {
        buffer.setLength(0);
        if (s != null) buffer.append(s);
        caret = buffer.length();
        clampCaret();
    }

    /**
     * Recall sent history by {@code dir} (-1 = older / UP, +1 = newer /
     * DOWN). Terminal semantics: the first UP stashes the live draft;
     * DOWN past the newest entry restores it. No-op when history is empty.
     */
    private void recallHistory(int dir) {
        if (SENT_HISTORY.isEmpty()) return;
        // ArrayDeque iteration is oldest→newest; index 0 must be the
        // NEWEST sent line, so address it from the tail.
        java.util.List<String> snap = new ArrayList<>(SENT_HISTORY);
        int newestFirst = snap.size() - 1; // index into snap of history pos 0
        if (dir < 0) {
            // UP — walk toward older entries.
            if (historyIndex == -1) liveDraft = buffer.toString();
            if (historyIndex < snap.size() - 1) historyIndex++;
            setBuffer(snap.get(newestFirst - historyIndex));
        } else {
            // DOWN — walk toward newer; past the newest returns to draft.
            if (historyIndex <= -1) return; // already on the live draft
            historyIndex--;
            if (historyIndex == -1) setBuffer(liveDraft);
            else setBuffer(snap.get(newestFirst - historyIndex));
        }
    }

    /** Push a just-sent line onto the shared history ring (newest last). */
    private static void pushHistory(String sent) {
        if (sent == null || sent.isEmpty()) return;
        // Avoid a duplicate when the user re-sends the immediately
        // previous line unchanged — keeps recall tidy like a shell.
        if (sent.equals(SENT_HISTORY.peekLast())) return;
        SENT_HISTORY.addLast(sent);
        while (SENT_HISTORY.size() > HISTORY_MAX) SENT_HISTORY.removeFirst();
    }

    private static int nameColor(String name) {
        return NAME_COLORS[Math.floorMod(name == null ? 0 : name.hashCode(), NAME_COLORS.length)];
    }

    private static String shortId(String id) {
        if (id == null) return "?";
        return id.length() > 6 ? id.substring(0, 6) : id;
    }

    private static int presenceCount(InputState st, String channel) {
        List<ServerEvent.User> p = st.presenceFor(channel);
        return p == null ? 0 : p.size();
    }

    /** Human-friendly channel name for the main header / input placeholder. */
    private static String channelDisplayName(String channel) {
        if (channel == null) return "?";
        if (ModConfig.CHANNEL_SERVER.equals(channel)) {
            String host = ShadowChatClient.get().currentServerHost();
            return host.isEmpty() ? "server" : host;
        }
        if (channel.startsWith("group:")) {
            ModConfig.Group g = ShadowChatClient.get().modConfig().findGroup(channel.substring("group:".length()));
            if (g != null && g.name != null && !g.name.isBlank()) return g.name;
            return shortId(channel.substring("group:".length()));
        }
        return channel;
    }

    /**
     * Cheap heuristic — was this line emitted from the coords-paste path?
     * Used to give the line a brand-blue highlight in the message list.
     */
    private static boolean looksLikeCoords(String text) {
        if (text == null) return false;
        return text.startsWith("X: ") && text.contains(" Y: ") && text.contains(" Z: ");
    }
}
