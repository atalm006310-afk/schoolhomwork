package app.shadowclient.chat.relay;

import app.shadowclient.chat.config.AuthConfig;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Thin wrapper around {@link java.net.http.WebSocket} that owns one
 * connection at a time to the Shadow Chat relay.
 *
 * <p>The mod creates a single {@code RelayClient} at startup and asks
 * it to {@link #connect(String, EventSink) connect} to a channel
 * whenever the active channel changes. Switching channels closes the
 * old socket first — the server enforces one-channel-per-socket.
 *
 * <p>All callbacks fire on the HTTP client's executor thread; the
 * caller (overlay/UI) must hop to the Minecraft client thread before
 * touching game state.
 */
public final class RelayClient {

    /** Callbacks invoked as the relay pushes events. Implementers must be thread-safe. */
    public interface EventSink {
        /** Connection established and ready to send. */
        default void onConnected(String channel) {}
        /** Connection closed (clean or unclean). {@code reason} is best-effort. */
        default void onDisconnected(String channel, String reason) {}
        /** A frame arrived — already parsed. */
        void onEvent(Messages.ServerEvent event);
        /**
         * A binary voice frame arrived from another participant on the
         * same channel. {@code sender} is the verified UUID stamped by
         * the relay; {@code opus} is the raw codec packet. Default no-op
         * so callers that don't care about voice (older sinks, tests)
         * keep working unchanged.
         */
        default void onVoice(UUID sender, byte[] opus) {}
    }

    /** Voice frame marker byte — first byte of every binary frame on the wire. */
    public static final byte FRAME_VOICE = 0x01;

    /** Hard cap on inbound binary frame size; anything bigger is silently dropped. */
    private static final int MAX_BINARY_FRAME_BYTES = 2048;

    private final HttpClient http;
    /**
     * Auth used for every connect/handshake. Volatile + swappable so the
     * mod can hot-replace an about-to-expire Microsoft token mid-session
     * (see {@link #setAuth}); the next {@link #connect} then rides the
     * fresh token without restarting the game.
     */
    private volatile AuthConfig auth;

    /**
     * Single in-flight socket. Holding {@code null} means we're idle.
     * We keep this as an atomic reference so a stray onClose for an
     * already-replaced socket doesn't clobber the new one.
     */
    private final AtomicReference<Session> current = new AtomicReference<>();

    /**
     * True when the user (or app shutdown) explicitly closed the
     * connection. Stops {@link #scheduleReconnect} from re-establishing
     * a connection the user already walked away from. Reset to false
     * on every explicit {@link #connect}.
     */
    private final AtomicBoolean manuallyDisconnected = new AtomicBoolean(false);

    public RelayClient(AuthConfig auth) {
        this.auth = auth;
        // Plain HttpClient with a sane connect timeout. The default
        // executor is a small ForkJoinPool which is fine for our
        // single-socket workload.
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        // Keepalive: Cloudflare's edge drops WebSockets that go quiet
        // for a minute or two, and an idle chat (nobody typing, no
        // presence churn) sends NOTHING. Every drop triggered the
        // auto-reconnect cycle — users saw periodic "Left server …"
        // spam while standing still. A protocol-level ping every 30s
        // keeps the connection non-idle; the edge answers the pong
        // itself, so the worker never even sees it.
        // The ping runs on sendExec like every other outbound op, so it
        // can never collide with a chat send (see enqueueSend).
        sendExec.scheduleAtFixedRate(() -> {
            Session s = current.get();
            if (s == null || s.socket == null) return;
            try {
                s.socket.sendPing(ByteBuffer.allocate(0)).join();
            } catch (Exception ignored) {
                // Dead socket — the listener's onClose/onError owns recovery.
            }
        }, 30, 30, java.util.concurrent.TimeUnit.SECONDS);
    }

    /** Connection-lifecycle log channel. These lines land in MC's
     *  latest.log, which makes disconnect storms / send failures
     *  visible to log-based diagnostics (doctor, support, the
     *  autonomous regression sweep) instead of existing only as
     *  ephemeral UI lines. */
    private static final org.slf4j.Logger LOG =
            org.slf4j.LoggerFactory.getLogger("shadow-chat");

    /**
     * Single-threaded executor that owns EVERY outbound socket op —
     * chat sends, voice frames, voice join/leave, keepalive pings.
     * java.net.http.WebSocket permits only one outstanding text/binary
     * send at a time; concurrent callers got IllegalStateException,
     * which the old fire-and-forget try/catch swallowed — i.e. a chat
     * message colliding with another in-flight send was DROPPED
     * silently. Funnelling everything through one thread (each op
     * joins before the next runs) makes collisions impossible.
     */
    private final java.util.concurrent.ScheduledExecutorService sendExec =
            java.util.concurrent.Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "shadow-chat-send");
                t.setDaemon(true);
                return t;
            });

    /** Run an outbound op on the send thread; log failures so they are
     *  diagnosable from latest.log instead of vanishing. */
    private void enqueueSend(String what, Runnable op) {
        sendExec.execute(() -> {
            try {
                op.run();
            } catch (Exception e) {
                LOG.warn("shadow-chat: {} failed: {}", what, rootCause(e));
            }
        });
    }

    /** Current channel string, or null if disconnected. */
    public String currentChannel() {
        Session s = current.get();
        return s == null ? null : s.channel;
    }

    /**
     * Swap in a fresh {@link AuthConfig} (e.g. after the launcher rewrote
     * shadow-chat-auth.json with a rotated Microsoft token). Takes effect
     * on the next {@link #connect} — callers that want the live socket to
     * ride the new token should follow this with a reconnect. Ignores null.
     */
    public void setAuth(AuthConfig fresh) {
        if (fresh != null) this.auth = fresh;
    }

    /**
     * Open (or replace) the active connection to the given channel.
     * Always closes the previous socket first.
     *
     * <p>Returns a future that completes when the upgrade succeeds.
     * Failures are surfaced via {@link EventSink#onDisconnected(String, String)}.
     */
    public CompletableFuture<Void> connect(String channel, EventSink sink) {
        // An explicit connect always re-enables auto-reconnect. The
        // reconnect path itself calls back into this method, so this
        // also handles "stay on this channel until the user says
        // otherwise" semantics across retries.
        manuallyDisconnected.set(false);
        closeCurrent("switching channel");

        if (!auth.isUsable()) {
            // Caller should have checked, but be defensive.
            sink.onDisconnected(channel, "not signed in");
            return CompletableFuture.completedFuture(null);
        }

        URI uri;
        try {
            uri = buildUri(auth.relayUrl(), auth.token(), channel, auth.name());
        } catch (Exception e) {
            sink.onDisconnected(channel, "bad relay URL: " + e.getMessage());
            return CompletableFuture.failedFuture(e);
        }

        Session session = new Session(channel, sink);
        // Stake our claim before kicking off the async build — if a
        // second connect() races us we want one of them to "win" and
        // the other to be cleanly torn down.
        current.set(session);

        return http.newWebSocketBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .buildAsync(uri, session.listener)
                .thenAccept(ws -> {
                    session.socket = ws;
                    LOG.info("shadow-chat: connected to {}", channel);
                    // Successful connect — clear the backoff counter so
                    // a future drop starts at 1s again, not at whatever
                    // delay we reached last time.
                    noteConnectedForBackoff();
                    sink.onConnected(channel);
                })
                .exceptionally(err -> {
                    LOG.warn("shadow-chat: connect to {} failed: {}", channel, rootCause(err));
                    // Connection failed — clear if we're still current
                    // and schedule a retry. Without this, only mid-session
                    // drops auto-retry; first-connect failures (DNS,
                    // 503, etc) would just stall forever.
                    current.compareAndSet(session, null);
                    sink.onDisconnected(channel, rootCause(err));
                    scheduleReconnect(channel, sink);
                    return null;
                });
    }

    /**
     * Send a chat message on the active connection. Silently dropped
     * if no connection is open — the overlay should already gate this
     * via its "not connected" state.
     */
    public void sendMessage(String text) {
        Session s = current.get();
        if (s == null || s.socket == null) return;
        enqueueSend("chat send", () -> s.socket.sendText(Messages.encodeMsg(text), true).join());
    }

    /**
     * Opt this connection in to voice. Until called, the relay won't
     * fan out anyone else's voice frames to us (and ours don't reach
     * anyone unless they've also opted in). Silently dropped if no
     * connection is open.
     */
    public void joinVoice() {
        Session s = current.get();
        if (s == null || s.socket == null) return;
        enqueueSend("voice join", () -> s.socket.sendText(Messages.encodeVoiceJoin(), true).join());
    }

    /** Opposite of {@link #joinVoice} — leave the voice room without disconnecting. */
    public void leaveVoice() {
        Session s = current.get();
        if (s == null || s.socket == null) return;
        enqueueSend("voice leave", () -> s.socket.sendText(Messages.encodeVoiceLeave(), true).join());
    }

    /**
     * Send a binary voice frame on the active connection. Uplink wire
     * format is {@code [FRAME_VOICE][opus...]} — the relay verifies the
     * sender from the socket's auth and prepends the sender UUID before
     * fanning out to peers, so we deliberately do NOT include any UUID
     * here.
     *
     * <p>Silently dropped if no connection is open or the opus payload
     * is empty / oversize. We don't surface errors here — voice frames
     * are inherently lossy and the next packet is along in 20 ms.
     */
    public void sendVoice(byte[] opus) {
        if (opus == null || opus.length == 0) return;
        if (opus.length + 1 > MAX_BINARY_FRAME_BYTES) return;
        Session s = current.get();
        if (s == null || s.socket == null) return;
        ByteBuffer buf = ByteBuffer.allocate(opus.length + 1);
        buf.put(FRAME_VOICE);
        buf.put(opus);
        buf.flip();
        sendExec.execute(() -> {
            try {
                s.socket.sendBinary(buf, true).join();
            } catch (Exception ignored) {
                // Voice is lossy by design — the next frame is 20 ms away.
            }
        });
    }

    /** Close the current socket if any. Safe to call multiple times.
     *  Suppresses any pending auto-reconnect — the user (or shutdown
     *  hook) explicitly wants out, we don't second-guess that. */
    public void disconnect() {
        manuallyDisconnected.set(true);
        nextReconnectAtMs = 0;
        closeCurrent("client closed");
    }

    /** Reconnect counter — drives the backoff schedule and the giveup cap. */
    private final java.util.concurrent.atomic.AtomicInteger reconnectAttempt =
            new java.util.concurrent.atomic.AtomicInteger(0);

    /**
     * Epoch-ms when the *next* scheduled reconnect attempt will fire.
     * 0 means "no reconnect pending". Published so the UI can render
     * a "Reconnecting in Ns…" countdown without polling the worker.
     */
    private volatile long nextReconnectAtMs = 0;

    /** Reset on a successful connect so the next failure starts at attempt #1. */
    void noteConnectedForBackoff() {
        reconnectAttempt.set(0);
        nextReconnectAtMs = 0;
    }

    /**
     * @return the epoch-ms timestamp of the next pending reconnect
     *         attempt, or 0 if no reconnect is currently scheduled.
     *         UI code can subtract this from System.currentTimeMillis()
     *         to render a live countdown.
     */
    public long nextReconnectAtMs() { return nextReconnectAtMs; }

    /**
     * Schedule a reconnect with exponential backoff: 1s, 2s, 4s, 8s, …
     * capped at 60s. Gives up after 10 attempts (~3 minutes total
     * elapsed) on the theory that if the relay is still down after that
     * the user has plenty of time to manually try again. Cleared by the
     * next successful connect via {@link #noteConnectedForBackoff}.
     */
    private void scheduleReconnect(String channel, EventSink sink) {
        if (manuallyDisconnected.get()) return;
        int attempt = reconnectAttempt.incrementAndGet();
        if (attempt > 10) {
            // Bail and tell the user. Next manual action resets the counter
            // because connect() flips manuallyDisconnected back to false.
            LOG.warn("shadow-chat: giving up on {} after 10 reconnect attempts", channel);
            sink.onDisconnected(channel, "giving up after 10 reconnect attempts");
            return;
        }
        long delayMs = Math.min(60_000L, 1000L * (1L << Math.min(6, attempt - 1)));
        LOG.info("shadow-chat: reconnect #{} to {} in {}ms", attempt, channel, delayMs);
        nextReconnectAtMs = System.currentTimeMillis() + delayMs;
        Thread t = new Thread(() -> {
            try { Thread.sleep(delayMs); }
            catch (InterruptedException e) { nextReconnectAtMs = 0; return; }
            // Re-check intent — user may have disconnected during the
            // wait, or another connect() may have already landed.
            if (manuallyDisconnected.get()) { nextReconnectAtMs = 0; return; }
            if (current.get() != null) { nextReconnectAtMs = 0; return; }
            // Clear before connect() so the UI doesn't read a stale
            // countdown while the new attempt is in flight.
            nextReconnectAtMs = 0;
            connect(channel, sink);
        }, "shadow-chat-reconnect-" + attempt);
        t.setDaemon(true);
        t.start();
    }

    private void closeCurrent(String reason) {
        Session s = current.getAndSet(null);
        if (s != null && s.socket != null) {
            try {
                s.socket.sendClose(WebSocket.NORMAL_CLOSURE, reason);
            } catch (Exception ignored) {
                // Best-effort. abort() is the hard kill.
                try { s.socket.abort(); } catch (Exception ignored2) {}
            }
        }
    }

    // ---------- internals ----------

    private static URI buildUri(String relayUrl, String token, String channel, String name) {
        // relayUrl may already have a trailing slash; normalize.
        String base = relayUrl;
        if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        // The relay expects ws://...; if the launcher gave us http(s)
        // by mistake, swap the scheme — the rest of the URI is identical.
        if (base.startsWith("https://")) base = "wss://" + base.substring("https://".length());
        else if (base.startsWith("http://")) base = "ws://" + base.substring("http://".length());

        String t = URLEncoder.encode(token, StandardCharsets.UTF_8);
        String c = URLEncoder.encode(channel, StandardCharsets.UTF_8);
        // Display name — the relay verifies the token offline (Mojang's
        // bot wall blocks the Worker's egress), and the token carries the
        // UUID but not the name, so we hand the relay our name for display.
        // Identity is still the token's verified UUID; this is cosmetic.
        String n = URLEncoder.encode(name == null ? "" : name, StandardCharsets.UTF_8);
        return URI.create(base + "/ws?token=" + t + "&channel=" + c + "&name=" + n);
    }

    private static String rootCause(Throwable t) {
        Throwable cur = t;
        while (cur.getCause() != null && cur.getCause() != cur) cur = cur.getCause();
        String msg = cur.getMessage();
        return msg == null ? cur.getClass().getSimpleName() : msg;
    }

    /** One open WebSocket plus the listener bound to its lifecycle. */
    private final class Session {
        final String channel;
        final EventSink sink;
        final Listener listener;
        volatile WebSocket socket;

        Session(String channel, EventSink sink) {
            this.channel = channel;
            this.sink = sink;
            this.listener = new Listener(this);
        }
    }

    /**
     * WebSocket listener. Buffers partial text frames since
     * {@link WebSocket.Listener#onText} can fire multiple times per
     * logical message (the API allows for chunking). Same buffering
     * applies to binary frames — JDK can deliver a fragmented payload.
     */
    private final class Listener implements WebSocket.Listener {
        private final Session session;
        private final StringBuilder buf = new StringBuilder();
        /**
         * Accumulator for partial binary frames. Allocated on demand
         * because most frames arrive in one piece on a healthy network
         * and we don't want to hold a 2 KB buffer per idle socket.
         */
        private ByteBuffer binBuf = null;

        Listener(Session session) {
            this.session = session;
        }

        @Override
        public void onOpen(WebSocket webSocket) {
            // Need to call request explicitly to receive messages —
            // java.net.http.WebSocket uses a pull model.
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            buf.append(data);
            if (last) {
                String full = buf.toString();
                buf.setLength(0);
                try {
                    Messages.ServerEvent ev = Messages.decode(full);
                    session.sink.onEvent(ev);
                } catch (Exception ignored) {
                    // Never let a callback exception kill the socket.
                }
            }
            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onBinary(WebSocket webSocket, ByteBuffer data, boolean last) {
            // Fast path: single-fragment frame and no accumulator yet.
            // We avoid the extra copy in the steady state.
            if (last && binBuf == null) {
                dispatchBinary(data);
            } else {
                // Slow path: accumulate fragments into binBuf.
                if (binBuf == null) {
                    // Cap the initial allocation at our hard limit so a
                    // misbehaving peer can't make us blow up memory.
                    int cap = Math.min(MAX_BINARY_FRAME_BYTES, data.remaining() + 256);
                    binBuf = ByteBuffer.allocate(cap);
                }
                if (binBuf.remaining() < data.remaining()) {
                    // Would overflow our cap → frame is too big, drop it.
                    binBuf = null;
                } else {
                    binBuf.put(data);
                    if (last) {
                        binBuf.flip();
                        dispatchBinary(binBuf);
                        binBuf = null;
                    }
                }
            }
            webSocket.request(1);
            return null;
        }

        /**
         * Decode a fully-assembled downlink binary frame and route it.
         * Downlink format: {@code [FRAME_VOICE][16-byte sender UUID][opus...]}.
         * Anything else is silently dropped — forward-compat for future
         * frame markers without breaking older clients.
         */
        private void dispatchBinary(ByteBuffer data) {
            try {
                int remaining = data.remaining();
                if (remaining < 1 || remaining > MAX_BINARY_FRAME_BYTES) return;
                byte marker = data.get();
                if (marker != FRAME_VOICE) return;
                // Downlink must include the 16-byte sender UUID stamped
                // by the relay. Anything shorter is a malformed/spoofed
                // frame; drop it.
                if (data.remaining() < 16 + 1) return;
                long msb = data.getLong();
                long lsb = data.getLong();
                UUID sender = new UUID(msb, lsb);
                byte[] opus = new byte[data.remaining()];
                data.get(opus);
                try {
                    session.sink.onVoice(sender, opus);
                } catch (Exception ignored) {
                    // Never let a callback exception kill the socket.
                }
            } catch (Exception ignored) {
                // Malformed frame — drop silently.
            }
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            // Only notify if we're still the live session — switching
            // channels triggers a close on the old socket that we
            // shouldn't surface to the UI as "you got disconnected".
            if (current.compareAndSet(session, null)) {
                LOG.warn("shadow-chat: disconnected from {} (code {}{})",
                        session.channel, statusCode,
                        reason == null || reason.isBlank() ? "" : ", " + reason);
                session.sink.onDisconnected(session.channel,
                        reason == null || reason.isBlank() ? "code " + statusCode : reason);
                // Retry on anything except a clean close. NORMAL_CLOSURE
                // (1000) means the close was deliberate (we asked for
                // it, or the relay banned/rate-limited us) — don't loop.
                // Everything else (1001 going-away from a Worker
                // redeploy, 1006 abnormal closure from a dropped
                // connection, etc.) is worth one retry.
                if (statusCode != WebSocket.NORMAL_CLOSURE) {
                    scheduleReconnect(session.channel, session.sink);
                }
            }
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            if (current.compareAndSet(session, null)) {
                LOG.warn("shadow-chat: socket error on {}: {}", session.channel, rootCause(error));
                session.sink.onDisconnected(session.channel, rootCause(error));
                scheduleReconnect(session.channel, session.sink);
            }
        }
    }
}
